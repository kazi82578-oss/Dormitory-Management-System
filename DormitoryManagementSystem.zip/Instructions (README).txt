Instructions to run "Dormitory Management System"

Create a new database named "DMS", open a new query window, and copy and paste all the contents inside the "Database Duplication Script (AutoGen).txt" file. Note that a bunch of errors will show up (because it attempts to drop tables that doesn't exist), but scroll down a bit and it should show a bunch of messages saying rows were affected.

Next, navigate to the project folder, "DMS V3 (Defence Version) - Optimised Booking" and open the "DMS.sln" using Visual Studio to open the project. Go the Solution Explorer and open the "ApplicationHelper.cs" file and edit value of the variable "ConnectionString" with the appropriate connection string (THIS IS A MUST).

PLEASE USE YOUR OWN STRING. The format and structure of my string is most likely different from the yours because I used Docker. If you do not know what that is, you shouldn't worry about it. Use the way you were taught in class on how to get the database connection string.

You should be set now, run the project and a login form will show up. The database already contains a bunch of sample data. To get the login credentials, run the following query and login to a user's account:

SELECT * FROM Users



If you face any difficulties, please directly contact the author and creator of the project:

EMAD
23-55527-3
https://www.facebook.com/emadharun.eh/