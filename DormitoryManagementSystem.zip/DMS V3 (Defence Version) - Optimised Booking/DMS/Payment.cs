﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS
{
    public partial class Payment : Form
    {
        string bkId;

        public Payment(string bookid)
        {
            InitializeComponent();
            bkId = bookid;
        }

        private void Payment_Load(object sender, EventArgs e)
        {
            this.dataLoad();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.dataLoad();
        }

        private void dataLoad()
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"select p.PaymentID, pm.MethodName, p.Amount, p.PaidAt from Payment as p inner join PaymentMethods as pm on p.MethodID = pm.MethodID where BookingID = {bkId}";
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                paymentInfo.AutoGenerateColumns = false;
                paymentInfo.DataSource = dt;
                paymentInfo.Refresh();
                paymentInfo.ClearSelection(); 
                con.Close();
            } catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
