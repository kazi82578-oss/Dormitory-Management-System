﻿namespace DMS
{
    partial class NewBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpLeaseStart = new System.Windows.Forms.DateTimePicker();
            this.dtpLeaseEnd = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTotalBill = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.dgvDormRoom = new System.Windows.Forms.DataGridView();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.txtRateID = new System.Windows.Forms.TextBox();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtCalculateBill = new System.Windows.Forms.Button();
            this.txtMonthlyBill = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDormRoom)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(255, 98);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Lease End:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(250, 66);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Lease Start:";
            // 
            // dtpLeaseStart
            // 
            this.dtpLeaseStart.Location = new System.Drawing.Point(340, 66);
            this.dtpLeaseStart.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtpLeaseStart.MaxDate = new System.DateTime(2028, 10, 10, 0, 0, 0, 0);
            this.dtpLeaseStart.MinDate = new System.DateTime(2025, 10, 9, 0, 0, 0, 0);
            this.dtpLeaseStart.Name = "dtpLeaseStart";
            this.dtpLeaseStart.Size = new System.Drawing.Size(194, 20);
            this.dtpLeaseStart.TabIndex = 10;
            // 
            // dtpLeaseEnd
            // 
            this.dtpLeaseEnd.Location = new System.Drawing.Point(341, 97);
            this.dtpLeaseEnd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtpLeaseEnd.Name = "dtpLeaseEnd";
            this.dtpLeaseEnd.Size = new System.Drawing.Size(194, 20);
            this.dtpLeaseEnd.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(268, 131);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "Total Bill:";
            // 
            // txtTotalBill
            // 
            this.txtTotalBill.Location = new System.Drawing.Point(341, 131);
            this.txtTotalBill.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtTotalBill.Name = "txtTotalBill";
            this.txtTotalBill.ReadOnly = true;
            this.txtTotalBill.Size = new System.Drawing.Size(193, 20);
            this.txtTotalBill.TabIndex = 13;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(271, 156);
            this.btnSubmit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(65, 27);
            this.btnSubmit.TabIndex = 14;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::DMS.Properties.Resources.House;
            this.pictureBox2.Location = new System.Drawing.Point(0, 2);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(69, 56);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // dgvDormRoom
            // 
            this.dgvDormRoom.AllowUserToAddRows = false;
            this.dgvDormRoom.AllowUserToDeleteRows = false;
            this.dgvDormRoom.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDormRoom.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column4,
            this.Column1,
            this.Column2,
            this.Column3});
            this.dgvDormRoom.Location = new System.Drawing.Point(12, 188);
            this.dgvDormRoom.Name = "dgvDormRoom";
            this.dgvDormRoom.ReadOnly = true;
            this.dgvDormRoom.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDormRoom.Size = new System.Drawing.Size(806, 185);
            this.dgvDormRoom.TabIndex = 16;
            this.dgvDormRoom.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDormRoom_CellClick);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.Location = new System.Drawing.Point(340, 156);
            this.btnRefresh.Margin = new System.Windows.Forms.Padding(2);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(78, 27);
            this.btnRefresh.TabIndex = 17;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // txtRateID
            // 
            this.txtRateID.Location = new System.Drawing.Point(73, 2);
            this.txtRateID.Margin = new System.Windows.Forms.Padding(2);
            this.txtRateID.Name = "txtRateID";
            this.txtRateID.ReadOnly = true;
            this.txtRateID.Size = new System.Drawing.Size(10, 20);
            this.txtRateID.TabIndex = 18;
            this.txtRateID.Visible = false;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "RateID";
            this.Column4.HeaderText = "ID";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.DataPropertyName = "DormName";
            this.Column1.HeaderText = "Dorm Name";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.DataPropertyName = "RoomType";
            this.Column2.HeaderText = "Room Type";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "MonthlyRent";
            this.Column3.HeaderText = "Monthly Rent";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // txtCalculateBill
            // 
            this.txtCalculateBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCalculateBill.Location = new System.Drawing.Point(422, 156);
            this.txtCalculateBill.Margin = new System.Windows.Forms.Padding(2);
            this.txtCalculateBill.Name = "txtCalculateBill";
            this.txtCalculateBill.Size = new System.Drawing.Size(113, 27);
            this.txtCalculateBill.TabIndex = 19;
            this.txtCalculateBill.Text = "Calculate Bill";
            this.txtCalculateBill.UseVisualStyleBackColor = true;
            this.txtCalculateBill.Click += new System.EventHandler(this.txtCalculateBill_Click);
            // 
            // txtMonthlyBill
            // 
            this.txtMonthlyBill.Location = new System.Drawing.Point(87, 2);
            this.txtMonthlyBill.Margin = new System.Windows.Forms.Padding(2);
            this.txtMonthlyBill.Name = "txtMonthlyBill";
            this.txtMonthlyBill.ReadOnly = true;
            this.txtMonthlyBill.Size = new System.Drawing.Size(10, 20);
            this.txtMonthlyBill.TabIndex = 20;
            this.txtMonthlyBill.Visible = false;
            // 
            // NewBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Wheat;
            this.ClientSize = new System.Drawing.Size(830, 385);
            this.Controls.Add(this.txtMonthlyBill);
            this.Controls.Add(this.txtCalculateBill);
            this.Controls.Add(this.txtRateID);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dgvDormRoom);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtTotalBill);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtpLeaseEnd);
            this.Controls.Add(this.dtpLeaseStart);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.Name = "NewBooking";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NewBooking";
            this.Load += new System.EventHandler(this.NewBooking_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDormRoom)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpLeaseStart;
        private System.Windows.Forms.DateTimePicker dtpLeaseEnd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTotalBill;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView dgvDormRoom;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.TextBox txtRateID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Button txtCalculateBill;
        private System.Windows.Forms.TextBox txtMonthlyBill;
    }
}