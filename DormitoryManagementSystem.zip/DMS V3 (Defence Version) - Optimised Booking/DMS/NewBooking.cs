﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DMS
{
    public partial class NewBooking : Form
    {
        
        public NewBooking()
        {
            InitializeComponent();
        }

        private void NewBooking_Load(object sender, EventArgs e)
        {
            this.dataLoad();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.dataLoad();
            txtRateID.Text = "";
            txtMonthlyBill.Text = "";
            txtTotalBill.Text = "";
        }

        private void dataLoad()
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"select drr.RateID, d.DormName, rt.RoomType, drr.MonthlyRent from DormRoomRate as drr inner join Dormitory as d on d.DormID = drr.DormID inner join RoomType as rt on rt.RoomTypeID = drr.RoomTypeID where d.DormGender = '{ApplicationHelper.CurrentUserGender}'";
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                dgvDormRoom.AutoGenerateColumns = false;
                dgvDormRoom.DataSource = dt;
                dgvDormRoom.Refresh();
                dgvDormRoom.ClearSelection();
                con.Close();
            } catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            int studentID = ApplicationHelper.CurrentUserID;
            string rateID = txtRateID.Text;
            string leaseStart = dtpLeaseStart.Value.ToString("yyyy-MM-dd");
            string leaseEnd = dtpLeaseEnd.Value.ToString("yyyy-MM-dd");
            string totalBill = txtTotalBill.Text;

            if (rateID == "")
            {
                MessageBox.Show("Select a dormitory and room type");
                return;
            }

            if (totalBill == "")
            {
                MessageBox.Show("Calculate bill");
                return;
            }

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"insert into Booking values({studentID}, {rateID}, '{leaseStart}', '{leaseEnd}', NULL, NULL, 'Pending', {totalBill})";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Booking created");
                con.Close();
                this.Close();
            } catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dgvDormRoom_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            txtRateID.Text = dgvDormRoom.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtMonthlyBill.Text = dgvDormRoom.Rows[e.RowIndex].Cells[3].Value.ToString();
        }

        private void txtCalculateBill_Click(object sender, EventArgs e)
        {
            if (txtMonthlyBill.Text == "" || txtRateID.Text == "")
            {
                MessageBox.Show("Select a dormitory and room type");
                return;
            }

            double monthlyBill = double.Parse(txtMonthlyBill.Text);
            DateTime leaseStart = dtpLeaseStart.Value.Date;
            DateTime leaseEnd = dtpLeaseEnd.Value.Date;

            int months = (leaseEnd.Year - leaseStart.Year) * 12 + (leaseEnd.Month - leaseStart.Month);
            if (leaseEnd.Day > leaseStart.Day)
            {
                months++;
            }
            else if (leaseEnd.Day < leaseStart.Day)
            {
                months--;
            }

            if (months <= 0)
            {
                MessageBox.Show("Lease should be at least 1 month");
                txtTotalBill.Text = "";
                return;
            }

            double totalBill = months * monthlyBill;
            txtTotalBill.Text = totalBill.ToString();
        }
    }
}
