﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS
{
    public static class ApplicationHelper
    {
        public static string ConnectionString = @"Data Source=localhost;Initial Catalog=DMS;User ID=sa;Password=Publicstaticvoidmain2006!;Encrypt=False";
        public static string CurrentUserName;
        public static string CurrentUserRole;
        public static int CurrentUserID;
        public static string CurrentUserGender;
    }
}
