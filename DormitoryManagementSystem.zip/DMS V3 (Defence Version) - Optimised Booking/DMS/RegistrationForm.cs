﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void btnShowNewPass_MouseHover(object sender, EventArgs e)
        {
            txtPass.UseSystemPasswordChar = false;
        }

        private void btnShowNewPass_MouseLeave(object sender, EventArgs e)
        {
            txtPass.UseSystemPasswordChar = true;
        }

        private void RegistrationForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.Owner != null)
            {
                this.Owner.Show();
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (this.Owner != null)
            {
                this.Owner.Show();
                this.Close();
            }
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            string Name = txtName.Text;
            string Email = txtEmail.Text;
            string Pass = txtPass.Text;
            string InstitutionID = txtInstitutionID.Text;

            string Dept = cmbDept.SelectedItem == null ? "" :
            cmbDept.SelectedItem.ToString();

            if (Name == "")
            {
                MessageBox.Show("Name not entered");
                return;
            }

            if (Email == "")
            {
                MessageBox.Show("Email not entered");
                return;
            }

            if (Pass == "")
            {
                MessageBox.Show("Pass not entered");
                return;
            }

            if (InstitutionID == "")
            {
                MessageBox.Show("Institute id not entered");
                return;
            }

            if (Dept == "")
            {
                MessageBox.Show("Dept not selected");
                return;
            }

            string Gender = "";
            if (rbMale.Checked)
            {
                Gender = "Male";
            }
            else if (rbFemale.Checked)
            {
                Gender = "Female";
            }
            else
            {
                MessageBox.Show("Gender not Selected");
                return;
            }

            string Program = "";
            if (rbBSc.Checked)
            {
                Program = "BSc";
            }
            else if (rbMSc.Checked)
            {
                Program = "MSc";
            }
            else
            {
                MessageBox.Show("Program not Selected");
                return;
            }

            string UserType = "Student";

            int YearsOfStudy = cmbYearsOfStudy.SelectedIndex+1;
            if (YearsOfStudy < 1)
            {
                MessageBox.Show("Year of study not selected");
                return;
            }

            String ContactInfo = txtPhone.Text;

            if (ContactInfo == "")
            {
                MessageBox.Show("Contact no not entered");
                return;
            }


            DateTime dob = dtpDOB.Value.Date;
            if (dob > DateTime.Now)
            {
                MessageBox.Show("Dob in future");
                return;
            }
                try
                {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"DECLARE @id int; Insert into dbo.Users Values('{Name}', '{Email}', '{Pass}','{UserType}', '{Gender}', '{ContactInfo}', '{dob.ToString("yyyy-MM-dd")}'); SET @id = CAST(SCOPE_IDENTITY() AS int); INSERT INTO StudentInfo VALUES (@id, '{InstitutionID}', '{Dept}', '{Program}', {YearsOfStudy});";
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("Registration Completed");

                if (this.Owner != null)
                {
                    this.Owner.Show();
                    this.Close();
                }

            }
                catch (Exception ex)
                {
                MessageBox.Show(ex.Message);

                }
        }
    }
}
