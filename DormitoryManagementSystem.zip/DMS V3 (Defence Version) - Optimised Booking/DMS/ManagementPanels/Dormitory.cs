﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS.ManagementPanels
{
    public partial class Dormitory : UserControl
    {
        public Dormitory()
        {
            InitializeComponent();
        }

        // <---------- EVENT HANDLERS ---------->
        private void Dormitory_Load(object sender, EventArgs e) // Load event to initialize data when the UserControl is loaded
        {
            this.LoadData();
            clearTimer.Start();
        }

        private void BtnNew_Click(object sender, EventArgs e) // New button to clear input fields for adding a new dormitory
        {
            this.ClearFields();
        }

        private void BtnDelete_Click(object sender, EventArgs e) // Delete button to remove the selected dormitory from the database
        {
            if (txtID.Text == "Auto Generated")
            {
                MessageBox.Show("Please select a dormitory to delete.");
                return;
            }

            var result = MessageBox.Show($"Are you sure you want to delete \"{txtName.Text}\"?", "Confirm Delete", MessageBoxButtons.YesNo);
            if (result == DialogResult.No) return;

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"DELETE FROM Dormitory WHERE DormID = {txtID.Text}";
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Delete Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();

            MessageBox.Show("Dormitory deleted successfully.", "Delete Successful");
        }

        private void BtnSave_Click(object sender, EventArgs e) // Save button to insert or update dormitory data in the database
        {
            if (!this.ValidateFields()) return;

            string dormName = txtName.Text.Trim();
            string dormGender = cbGender.SelectedItem.ToString();
            short dormCapacity = short.Parse(txtCapacity.Text.Trim());

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;

                if (txtID.Text == "Auto Generated") // Insert new dormitory
                {
                    cmd.CommandText = $"INSERT INTO Dormitory VALUES('{dormName}', '{dormGender}', {dormCapacity})";
                }
                else // Update existing dormitory
                {
                    cmd.CommandText = $"UPDATE Dormitory SET DormName = '{dormName}', DormGender = '{dormGender}', DormCapacity = {dormCapacity} WHERE DormID = {txtID.Text}";
                }

                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Save Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();

            MessageBox.Show("Dormitory saved successfully.", "Save Successful");
        }

        private void BtnRefresh_Click(object sender, EventArgs e) // Refresh button to reload data from the database
        {
            this.LoadData();
            this.ClearFields();
        }

        private void DgvDorm_CellClick(object sender, DataGridViewCellEventArgs e) // Cell click event to populate input fields with the selected dormitory's data
        {
            if (e.RowIndex < 0) return;

            txtID.Text = dgvDorm.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtName.Text = dgvDorm.Rows[e.RowIndex].Cells[1].Value.ToString();
            cbGender.SelectedItem = dgvDorm.Rows[e.RowIndex].Cells[2].Value;
            txtCapacity.Text = dgvDorm.Rows[e.RowIndex].Cells[3].Value.ToString();
        }

        private void ClearTimer_Tick(object sender, EventArgs e) // Timer to clear selection in the DataGridView after a short delay
        {
            dgvDorm.ClearSelection();
            clearTimer.Stop();
        }

        // <---------- HELPER METHODS ---------->
        private void LoadData() // Load data from the database and display it in the DataGridView
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "SELECT * FROM Dormitory ORDER BY DormID";

                var adp = new SqlDataAdapter(cmd);
                var dt = new DataTable();
                adp.Fill(dt);
                con.Close();

                dgvDorm.AutoGenerateColumns = false;
                dgvDorm.DataSource = dt;
                dgvDorm.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Load Failed");
                return;
            }
        }

        private void ClearFields() // Clear input fields and reset the form state
        {
            txtID.Text = "Auto Generated";
            txtName.Text = "";
            cbGender.SelectedIndex = -1;
            txtCapacity.Text = "";
            dgvDorm.ClearSelection();
        }

        private bool ValidateFields() // Validate input fields before saving
        {
            string dormName = txtName.Text.Trim();
            // string dormGender = cbGender.SelectedItem == null ? "" : cbGender.SelectedItem.ToString();
            sbyte dormGenderIndex = (sbyte) cbGender.SelectedIndex;
            string dormCapacityText = txtCapacity.Text.Trim();
            short dormCapacity;

            if (string.IsNullOrWhiteSpace(dormName)) // Validate that dormitory name is not empty
            {
                MessageBox.Show("Please enter a valid dormitory name.", "Validation Error");
                return false;
            }

            if (dormName.Length < 1 || dormName.Length > 128) // Validate that dormitory name length is within acceptable range
            {
                MessageBox.Show("Dormitory name must be between 1 and 128 characters.", "Validation Error");
                return false;
            }

            if (txtID.Text == "Auto Generated") // Only check for duplicates when adding a new dormitory
            {
                for (int i = 0; i < dgvDorm.Rows.Count; i++)
                {
                    if (dormName.Equals(dgvDorm.Rows[i].Cells[1].Value.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show("Dormitory name already exists. Please enter a different name.", "Validation Error");
                        return false;
                    }
                }
            }

            if (dormGenderIndex < 0) // Check if a gender is selected
            {
                MessageBox.Show("Please select a gender.", "Validation Error");
                return false;
            }

            try // Validate that capacity is a valid short
            {
                dormCapacity = short.Parse(dormCapacityText);
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter a valid capacity.", "Validation Error");
                return false;
            }

            if (dormCapacity < 1 || dormCapacity > 32767) // Validate that capacity is within acceptable range
            {
                MessageBox.Show("Capacity must be between 1 and 32,767.", "Validation Error");
                return false;
            }

            return true; // All validations passed
        }
    }
}
