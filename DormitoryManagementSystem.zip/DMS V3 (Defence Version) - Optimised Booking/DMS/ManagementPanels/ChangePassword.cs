﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS.ManagementPanels
{
    public partial class ChangePassword : Form
    {
        public ChangePassword()
        {
            InitializeComponent();
        }

        private void BtnSave_Click(object sender, EventArgs e) // Save button to validate and update password
        {
            if (!this.ValidatePassword()) return;

            this.UpdatePassword();
        }

        private void BtnCancel_Click(object sender, EventArgs e) // Cancel button to close the form
        {
            this.Close();
        }

        private bool ValidatePassword() // Validate password to ensure both match
        {
            string pass = txtPass.Text;
            string confPass = txtConfPass.Text;

            if (string.IsNullOrWhiteSpace(pass))
            {
                MessageBox.Show("Please enter a valid password", "Validation Failed");
                return false;
            }

            if (pass != confPass) // Check if passwords match
            {
                MessageBox.Show("Passwords do not match.", "Validation Failed");
                return false;
            }

            if (pass.Length < 7 || pass.Length > 256) // Check password length
            {
                MessageBox.Show("Password must be between 7 and 256 characters.", "Validation Failed");
                return false;
            }

            return true; // All validations passed
        }

        private void UpdatePassword() // Update the password
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"UPDATE Users SET Password = '{txtPass.Text}' WHERE UserID = {ApplicationHelper.CurrentUserID}";
                cmd.ExecuteNonQuery();
                con.Close();
            } catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Password Update Failed");
                return;
            }

            MessageBox.Show("Password updated successfully");
            this.Close();
        }
    }
}
