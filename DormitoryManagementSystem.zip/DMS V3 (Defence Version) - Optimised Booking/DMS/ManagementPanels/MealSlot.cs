﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS.ManagementPanels
{
    public partial class MealSlot : UserControl
    {
        public MealSlot()
        {
            InitializeComponent();
        }

        private void dataLoad()
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "select * from MealSlot";

                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                dgvMeal.AutoGenerateColumns = false;
                dgvMeal.DataSource = dt;
                dgvMeal.Refresh();
                dgvMeal.ClearSelection();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void resetFields()
        {
            dgvMeal.ClearSelection();
            idField.Text = "Auto Generated";
            slotNameField.Text = "";
            descriptionField.Text = "";
            priceField.Text = "";
        }

        private void MealSlot_Load(object sender, EventArgs e)
        {
            this.dataLoad();
        }

        private void newButton_Click(object sender, EventArgs e)
        {
            this.resetFields();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (idField.Text == "Auto Generated")
            {
                MessageBox.Show("Please select a meal slot to delete.");
                return;
            }

            var result = MessageBox.Show($"Are you sure you want to delete?", "Delete Confirmation", MessageBoxButtons.YesNo);
            if (result == DialogResult.No) return;

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"delete from MealSlot where SlotID = {idField.Text}";
                cmd.ExecuteNonQuery();

                MessageBox.Show("Meal slot deleted successfully.");
                this.dataLoad();
                this.resetFields();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            this.dataLoad();
            this.resetFields();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            string slotName = slotNameField.Text;
            string slotDescription = descriptionField.Text;
            string monthlyPrice = priceField.Text;
            string query;

            if (slotName == "")
            {
                MessageBox.Show("Please enter a slot name.");
                return;
            }

            if (slotDescription == "")
            {
                MessageBox.Show("Please enter a slot description.");
                return;
            }

            if (monthlyPrice == "")
            {
                MessageBox.Show("Please enter a valid monthly price.");
                return;
            }

            if (idField.Text == "Auto Generated")
            {
                query = $"insert into MealSlot values('{slotName}', {monthlyPrice}, '{slotDescription}')";
            }
            else
            {
                query = $"update MealSlot set SlotName = '{slotName}', MonthlyPrice = {monthlyPrice}, Description = '{slotDescription}' where SlotID = {idField.Text}";

            }

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();
                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = query;
                cmd.ExecuteNonQuery();
                MessageBox.Show("Meal slot saved successfully.");
                this.dataLoad();
                this.resetFields();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dgvMeal_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            idField.Text = dgvMeal.Rows[e.RowIndex].Cells[0].Value.ToString();
            slotNameField.Text = dgvMeal.Rows[e.RowIndex].Cells[1].Value.ToString();
            descriptionField.Text = dgvMeal.Rows[e.RowIndex].Cells[2].Value.ToString();
            priceField.Text = dgvMeal.Rows[e.RowIndex].Cells[3].Value.ToString();
        }
    }
}
