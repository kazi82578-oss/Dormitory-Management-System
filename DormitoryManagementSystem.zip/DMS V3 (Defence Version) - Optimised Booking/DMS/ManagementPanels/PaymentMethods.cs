﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS.ManagementPanels
{
    public partial class PaymentMethods : UserControl
    {
        public PaymentMethods()
        {
            InitializeComponent();
        }

        // <--------------------- Event Handlers ----------------->

        private void PaymentMethods_Load(object sender, EventArgs e) // Load event to initialize data when the UserControl is loaded
        {
            this.LoadData();
            clearTimer.Start();
        }

        private void BtnNew_Click(object sender, EventArgs e) // New button to clear input fields for adding a new payment method
        {
            this.ClearFields();
        }

        private void BtnDelete_Click(object sender, EventArgs e) // Delete button to remove the selected payment method from the database
        {
            if (txtID.Text == "Auto Generated")
            {
                MessageBox.Show("Please select a payment method to delete.");
                return;
            }

            var result = MessageBox.Show($"Are you sure you want to delete \"{txtMethodName.Text}\"?", "Confirm Delete", MessageBoxButtons.YesNo);
            if (result == DialogResult.No) return;

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"DELETE FROM PaymentMethods WHERE MethodID = {txtID.Text}";
                cmd.ExecuteNonQuery();
                con.Close();
            } catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Delete Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();

            MessageBox.Show("Payment method deleted successfully.", "Delete Successful");
        }

        private void BtnRefresh_Click(object sender, EventArgs e) // Refresh button to reload data from the database
        {
            this.LoadData();
            this.ClearFields();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (!this.ValidateFields()) return; // Validate inputs before saving

            string methodName = txtMethodName.Text.Trim();

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                
                if (txtID.Text == "Auto Generated") // Insert new payment method
                {
                    cmd.CommandText = $"INSERT INTO PaymentMethods VALUES('{methodName}')";
                }
                else // Update existing payment method
                {
                    cmd.CommandText = $"UPDATE PaymentMethods SET MethodName = '{methodName}' WHERE MethodID = {txtID.Text}";
                }

                cmd.ExecuteNonQuery();
                con.Close();
            } catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Save Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();

            MessageBox.Show("Payment method saved successfully.", "Save Successful");
        }

        private void DgvPaymentMethods_CellClick(object sender, DataGridViewCellEventArgs e) // Handle cell click event to populate input fields with selected row data
        {
            if (e.RowIndex < 0) return;

            txtID.Text = dgvPaymentMethods.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtMethodName.Text = dgvPaymentMethods.Rows[e.RowIndex].Cells[1].Value.ToString();
        }

        private void ClearTimer_Tick(object sender, EventArgs e) // Timer to clear selection in DataGridView after a short interval
        {
            dgvPaymentMethods.ClearSelection();
            clearTimer.Stop();
        }

        // <--------------------- Internal Helper Methods ----------------->

        private void LoadData() // Load data from the database and display it in the DataGridView
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "SELECT * FROM PaymentMethods ORDER BY MethodID";

                var adp = new SqlDataAdapter(cmd);
                var dt = new DataTable();

                adp.Fill(dt);
                con.Close();

                dgvPaymentMethods.AutoGenerateColumns = false;
                dgvPaymentMethods.DataSource = dt;
                dgvPaymentMethods.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Load Failed");
                return;
            }
        }

        private void ClearFields() // Clear input fields and reset the form state
        {
            txtID.Text = "Auto Generated";
            txtMethodName.Text = "";
            dgvPaymentMethods.ClearSelection();
        }

        private bool ValidateFields() // Validate user inputs before saving to the database
        {
            string methodName = txtMethodName.Text.Trim();
            if (string.IsNullOrWhiteSpace(methodName)) // Validate that the payment method name is not empty
            {
                MessageBox.Show("Please enter a valid payment method name.", "Validation Error");
                return false;
            }

            if (methodName.Length < 1 || methodName.Length > 64) // Validate that the payment method name length is within acceptable range
            {
                MessageBox.Show("Payment method name must be between 1 and 64 characters.", "Validation Error");
                return false;
            }

            for (int i = 0; i < dgvPaymentMethods.Rows.Count; i++) // Check for duplicate payment method names in the DataGridView
            {
                if (dgvPaymentMethods.Rows[i].Cells[1].Value.ToString().Equals(methodName, StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("This payment method already exists. Please enter a different name.", "Validation Error");
                    return false;
                }
            }

            // TODO: Reject number-only inputs

            return true; // All validations passed
        }
    }
}
