﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace DMS.ManagementPanels
{
    public partial class Booking : UserControl
    {
        string bookingID = "Unselected", bookingStatus, totalBill, foodStart, foodEnd, wardenDormID;

        public Booking()
        {
            InitializeComponent();
        }

        // <--------------------- Event Handlers ----------------->

        private void Booking_Load(object sender, EventArgs e) // Load event to initialize data when the UserControl is loaded
        {
            if (ApplicationHelper.CurrentUserRole == "Warden")
            {
                this.WardenDormID();
            }

            this.LoadData();
            clearTimer.Start();
        }

        private void BtnRefresh_Click(object sender, EventArgs e) // Refresh button to reload data from the database
        {
            this.LoadData();
            this.ClearFields();
        }

        private void BtnDelete_Click(object sender, EventArgs e) // Delete button event handler to remove a selected booking from the database
        {
            if (bookingID == "Unselected")
            {
                MessageBox.Show("Please select a booking to delete.");
                return;
            }

            var result = MessageBox.Show($"Are you sure you want to delete?\nAny associated payment records will also be deleted.", "Confirm Delete", MessageBoxButtons.YesNo);
            if (result == DialogResult.No) return;

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"DELETE FROM Booking WHERE BookingID = {bookingID}";
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Delete Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();

            MessageBox.Show("Entry deleted successfully.", "Delete Successful");
        }

        private void BtnConfirm_Click(object sender, EventArgs e) // Confirm button event handler to confirm a booking
        {
            this.UpdateBookingStatus(isConfirm: true);
        }

        private void BtnReject_Click(object sender, EventArgs e) // Reject button event handler to confirm a booking
        {
            this.UpdateBookingStatus(isConfirm: false);
        }

        private void BtnCollectPayment_Click(object sender, EventArgs e) // Payment button event handler for the selected booking
        {
            if (bookingID == "Unselected")
            {
                MessageBox.Show("Please select a booking to proceed.");
                return;
            }

            if (bookingStatus == "Pending" || bookingStatus == "Cancelled" || bookingStatus == "Rejected")
            {
                MessageBox.Show("Payments can only be collected for 'Confirmed' bookings.");
                return;
            }

            Payment paymentForm = new Payment(int.Parse(bookingID), double.Parse(totalBill));
            paymentForm.Show();
        }

        private void BtnFoodBooking_Click(object sender, EventArgs e) // Show meal slots booked
        {
            if (bookingID == "Unselected")
            {
                MessageBox.Show("Please select a booking to proceed.");
                return;
            }

            if (string.IsNullOrWhiteSpace(foodStart) || string.IsNullOrWhiteSpace(foodEnd))
            {
                MessageBox.Show("Selected booking has no food bookings.");
                return;
            }

            this.LoadFoodData();
        }

        private void BtnApplyFilters_Click(object sender, EventArgs e) // Process filters
        {
            string whereConditions;
            if (!this.ValidateFilters(out whereConditions)) return;
            this.LoadData(whereConditions);
            this.ClearFields();
        }

        private void BtnResetFilters_Click(object sender, EventArgs e) // Reset Filters button to clear all filter controls
        {
            this.ResetFilters();
            this.LoadData();
            this.ClearFields();
        }

        private void DgvBooking_CellClick(object sender, DataGridViewCellEventArgs e) // Cell click event to populate input fields with the selected booking's data
        {
            if (e.RowIndex < 0) return;
            bookingID = dgvBooking.Rows[e.RowIndex].Cells[0].Value.ToString();
            bookingStatus = dgvBooking.Rows[e.RowIndex].Cells[8].Value.ToString();
            totalBill = dgvBooking.Rows[e.RowIndex].Cells[9].Value.ToString();
            foodStart = dgvBooking.Rows[e.RowIndex].Cells[6].Value.ToString();
            foodEnd = dgvBooking.Rows[e.RowIndex].Cells[7].Value.ToString();
        }

        private void ClearTimer_Tick(object sender, EventArgs e) // Timer tick event to clear selection in the DataGridView periodically
        {
            dgvBooking.ClearSelection();
            clearTimer.Stop();
        }

        // <--------------------- Internal Helper Methods ----------------->

        private void LoadData(string whereCond = "") // Method to load booking data from the database and display it in the DataGridView
        {
            string dgvQuery;
            if (string.IsNullOrWhiteSpace(whereCond))
            {
                if (ApplicationHelper.CurrentUserRole != "Warden") // For Admins
                {
                    dgvQuery = "SELECT B.BookingID, U.Name, D.DormName, RT.RoomType, B.LeaseStart, B.LeaseEnd, B.FoodStart, B.FoodEnd, B.Status, B.TotalBill FROM Booking AS B INNER JOIN StudentInfo AS S ON B.StudentID = S.StudentID INNER JOIN Users AS U ON S.StudentID = U.UserID INNER JOIN DormRoomRate AS DRR ON B.RateID = DRR.RateID INNER JOIN Dormitory AS D ON DRR.DormID = D.DormID INNER JOIN RoomType AS RT ON DRR.RoomTypeID = RT.RoomTypeID ORDER BY B.BookingID;";
                }
                else // For Wardens
                {
                    dgvQuery = $"SELECT B.BookingID, U.Name, D.DormName, RT.RoomType, B.LeaseStart, B.LeaseEnd, B.FoodStart, B.FoodEnd, B.Status, B.TotalBill FROM Booking AS B INNER JOIN StudentInfo AS S ON B.StudentID = S.StudentID INNER JOIN Users AS U ON S.StudentID = U.UserID INNER JOIN DormRoomRate AS DRR ON B.RateID = DRR.RateID INNER JOIN Dormitory AS D ON DRR.DormID = D.DormID INNER JOIN RoomType AS RT ON DRR.RoomTypeID = RT.RoomTypeID WHERE D.DormID = {wardenDormID} ORDER BY B.BookingID;";
                }
            }
            else
            {
                if (ApplicationHelper.CurrentUserRole != "Warden") // For Admins
                {
                    dgvQuery = $"SELECT B.BookingID, U.Name, D.DormName, RT.RoomType, B.LeaseStart, B.LeaseEnd, B.FoodStart, B.FoodEnd, B.Status, B.TotalBill FROM Booking AS B INNER JOIN StudentInfo AS S ON B.StudentID = S.StudentID INNER JOIN Users AS U ON S.StudentID = U.UserID INNER JOIN DormRoomRate AS DRR ON B.RateID = DRR.RateID INNER JOIN Dormitory AS D ON DRR.DormID = D.DormID INNER JOIN RoomType AS RT ON DRR.RoomTypeID = RT.RoomTypeID WHERE {whereCond} ORDER BY B.BookingID;";
                }
                else // For Wardens
                {
                    dgvQuery = $"SELECT B.BookingID, U.Name, D.DormName, RT.RoomType, B.LeaseStart, B.LeaseEnd, B.FoodStart, B.FoodEnd, B.Status, B.TotalBill FROM Booking AS B INNER JOIN StudentInfo AS S ON B.StudentID = S.StudentID INNER JOIN Users AS U ON S.StudentID = U.UserID INNER JOIN DormRoomRate AS DRR ON B.RateID = DRR.RateID INNER JOIN Dormitory AS D ON DRR.DormID = D.DormID INNER JOIN RoomType AS RT ON DRR.RoomTypeID = RT.RoomTypeID WHERE D.DormID = {wardenDormID} AND {whereCond} ORDER BY B.BookingID;";
                }
            }


            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = dgvQuery + "SELECT D.DormID, D.DormName FROM Dormitory AS D; SELECT RT.RoomTypeID, RT.RoomType FROM RoomType AS RT ORDER BY RT.RoomTypeID";
                var adp = new SqlDataAdapter(cmd);
                var ds = new DataSet();
                adp.Fill(ds);
                con.Close();

                dgvBooking.AutoGenerateColumns = false;
                dgvBooking.DataSource = ds.Tables[0];
                dgvBooking.Refresh();

                if (string.IsNullOrWhiteSpace(whereCond)) // Only run when actually loading data (ds has three tables), not when filters are being applied
                {
                    cbDorm.DataSource = ds.Tables[1];
                    cbDorm.DisplayMember = "DormName";
                    cbDorm.ValueMember = "DormID";

                    if (ApplicationHelper.CurrentUserRole != "Warden") // Clear selection in Dorm for Admins in Filters
                    {
                        cbDorm.SelectedIndex = -1;
                    }
                    else // Select Warden's Dorm in Filters
                    {
                        cbDorm.SelectedValue = wardenDormID;
                    }

                    cbRoomType.DataSource = ds.Tables[2];
                    cbRoomType.DisplayMember = "RoomType";
                    cbRoomType.ValueMember = "RoomTypeID";
                    cbRoomType.SelectedIndex = -1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Load Failed");
                return;
            }
        }

        private void LoadFoodData() // Show slots booked against booking ID
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"SELECT MS.SlotName FROM BookingFood AS BF INNER JOIN MealSlot AS MS ON BF.SlotID = MS.SlotID WHERE BookingID = {bookingID} ORDER BY MS.SlotID";
                var adp = new SqlDataAdapter(cmd);
                var dt = new DataTable();
                adp.Fill(dt);
                con.Close();

                // var msg = string.Join(Environment.NewLine, dt.Rows.Cast<DataRow>().Select(r => r[0]?.ToString()));
                string slotNames = "";
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    slotNames += dt.Rows[i]["SlotName"].ToString() + "\n";
                }

                MessageBox.Show($"Food Start: {foodStart}\nFood End: {foodEnd}\n\nItems:\n{slotNames}", "Slots Booked");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Load Failed");
                return;
            }
        }

        private void ClearFields() // Method to clear input fields and reset the form state
        {
            bookingID = "Unselected";
            bookingStatus = "";
            totalBill = "";
            foodStart = "";
            foodEnd = "";
            dgvBooking.ClearSelection();
        }

        private void ResetFilters() // Method to reset filter controls to their default state
        {
            chbName.Checked = false;
            txtStudentName.Text = "";

            chbDorm.Checked = false;
            cbDorm.SelectedIndex = -1;

            chbRoomType.Checked = false;
            cbRoomType.SelectedIndex = -1;

            chbLeaseStart.Checked = false;
            dtpLeaseStart.Value = DateTime.Now;

            chbLeaseEnd.Checked = false;
            dtpLeaseEnd.Value = DateTime.Now;

            chbStatus.Checked = false;
            cbStatus.SelectedIndex = -1;
        }

        private bool ValidateFilters(out string whereClause) // Method to validate filter inputs before applying them
        {
            whereClause = "";

            string studentName = txtStudentName.Text.Trim();
            int dormIndex = cbDorm.SelectedIndex;
            int roomTypeIndex = cbRoomType.SelectedIndex;
            DateTime leaseStart = dtpLeaseStart.Value;
            DateTime leaseEnd = dtpLeaseEnd.Value;
            sbyte statusIndex = (sbyte)cbStatus.SelectedIndex;

            if (chbName.Checked) // Validate Student Name
            {
                if (string.IsNullOrWhiteSpace(studentName))
                {
                    MessageBox.Show("Please enter a student name to filter by.", "Validation Error");
                    return false;
                }

                if (studentName.Length < 1 || studentName.Length > 128)
                {
                    MessageBox.Show("Student name must be between 1 and 128 characters.", "Validation Error");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(whereClause)) // Query construction logic
                {
                    whereClause = $"U.Name LIKE '%{studentName}%'";
                }
                else
                {
                    whereClause += $" AND U.Name LIKE '%{studentName}%'";
                }
            }

            if (chbDorm.Checked) // Validate Dorm
            {
                if (dormIndex < 0)
                {
                    MessageBox.Show("Please select a dormitory to filter by.", "Validation Error");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(whereClause)) // Query construction logic
                {
                    whereClause = $"D.DormID = {cbDorm.SelectedValue}";
                }
                else
                {
                    whereClause += $" AND D.DormID = {cbDorm.SelectedValue}";
                }
            }

            if (chbRoomType.Checked) // Validate Room Type
            {
                if (roomTypeIndex < 0)
                {
                    MessageBox.Show("Please select a room type to filter by.", "Validation Error");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(whereClause)) // Query construction logic
                {
                    whereClause = $"RT.RoomTypeID = {cbRoomType.SelectedValue}";
                }
                else
                {
                    whereClause += $" AND RT.RoomTypeID = {cbRoomType.SelectedValue}";
                }
            }

            if (chbLeaseStart.Checked) // Validate Lease Start Date
            {
                if (leaseStart > DateTime.Now)
                {
                    MessageBox.Show("Lease start date cannot be in the future.", "Validation Error");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(whereClause)) // Query construction logic
                {
                    whereClause = $"B.LeaseStart = '{leaseEnd.ToString("yyyy-MM-dd")}'";
                }
                else
                {
                    whereClause += $" AND B.LeaseStart = '{leaseEnd.ToString("yyyy-MM-dd")}'";
                }
            }

            if (chbLeaseEnd.Checked)
            {
                if (string.IsNullOrWhiteSpace(whereClause)) // Query construction logic
                {
                    whereClause = $"B.LeaseEnd = '{leaseEnd.ToString("yyyy-MM-dd")}'";
                }
                else
                {
                    whereClause += $" AND B.LeaseEnd = '{leaseEnd.ToString("yyyy-MM-dd")}'";
                }
            }

            if (chbLeaseStart.Checked && chbLeaseEnd.Checked) // Validate Lease End Date
            {
                if (leaseEnd < leaseStart)
                {
                    MessageBox.Show("Lease end date cannot be before lease start date.", "Validation Error");
                    return false;
                }
            }

            if (chbStatus.Checked) // Validate Status
            {
                if (statusIndex < 0)
                {
                    MessageBox.Show("Please select a status to filter by.", "Validation Error");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(whereClause)) // Query construction logic
                {
                    whereClause = $"B.Status = '{cbStatus.SelectedItem}'";
                }
                else
                {
                    whereClause += $" AND B.Status = '{cbStatus.SelectedItem}'";
                }

            }

            if (string.IsNullOrWhiteSpace(whereClause))
            {
                MessageBox.Show("Please select some filters to apply.", "Validation Error");
                return false;
            }

            return true; // All validations passed
        }

        private void WardenDormID() // Get the Warden's Dorm ID
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"SELECT WI.DormID FROM WardenInfo AS WI WHERE WI.WardenID = {ApplicationHelper.CurrentUserID}";
                var adp = new SqlDataAdapter(cmd);
                var dt = new DataTable();
                adp.Fill(dt);
                con.Close();

                // var wardenDormID = string.Join(Environment.NewLine, dt.Rows.Cast<DataRow>().Select(r => r[0]?.ToString()));

                this.wardenDormID = dt.Rows[0]["DormID"].ToString();
                chbDorm.Enabled = false;
                cbDorm.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Load Failed");
                return;
            }
        }

        private void UpdateBookingStatus(bool isConfirm) // Update booking status
        {
            string bookingStatus = isConfirm ? "Confirmed" : "Rejected";
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"UPDATE Booking SET Status = '{bookingStatus}' WHERE BookingID = {bookingID}";
                cmd.ExecuteNonQuery();
                con.Close();
            } catch (Exception)
            {
                MessageBox.Show($"Failed to {bookingStatus} booking. Please try again.", "Status Update Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();
            MessageBox.Show($"Successfully updated booking status.", "Status Update Succeeded");
        }
    }
}
