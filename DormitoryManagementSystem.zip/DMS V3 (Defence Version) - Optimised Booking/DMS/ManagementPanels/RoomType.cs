﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS.ManagementPanels
{
    public partial class RoomType : UserControl
    {
        public RoomType()
        {
            InitializeComponent();
        }

        private void dataLoad()
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "select * from RoomType";

                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                dgvRoomType.AutoGenerateColumns = false;
                dgvRoomType.DataSource = dt;
                dgvRoomType.Refresh();
                dgvRoomType.ClearSelection();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void resetField()
        {
            idField.Text = "Auto Generated";
            typeField.Text = "";
            capacityField.Text = "";
            dgvRoomType.ClearSelection();
        }

        private void RoomType_Load(object sender, EventArgs e)
        {
            this.dataLoad();
        }

        private void newButton_Click(object sender, EventArgs e)
        {
            this.resetField();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (idField.Text == "Auto Generated")
            {
                MessageBox.Show("Please select a room type to delete.");
                return;
            }

            var result = MessageBox.Show($"Are you sure you want to delete?", "Delete Confirmation", MessageBoxButtons.YesNo);
            if (result == DialogResult.No) return;

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();
                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"delete from RoomType where RoomTypeID = {idField.Text}";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Room type deleted successfully.");
                this.dataLoad();
                this.resetField();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            this.dataLoad();
            this.resetField();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            string roomType = typeField.Text;
            string roomCapacity = capacityField.Text;
            string query;

            if (roomType == "")
            {
                MessageBox.Show("Please enter a valid room type.");
                return;
            }

            if (roomCapacity == "")
            {
                MessageBox.Show("Please enter a valid capacity.");
                return;
            }

            if (idField.Text == "Auto Generated")
            {
                query = $"insert into RoomType values('{roomType}', {roomCapacity})";
            }
            else
            {
                query = $"update RoomType set RoomType = '{roomType}', RoomCapacity = {roomCapacity} where RoomTypeID = {idField.Text}";
            }

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();
                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = query;
                cmd.ExecuteNonQuery();
                MessageBox.Show("Room type saved successfully.");
                this.dataLoad();
                this.resetField();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dgvRoomType_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            idField.Text = dgvRoomType.Rows[e.RowIndex].Cells[0].Value.ToString();
            typeField.Text = dgvRoomType.Rows[e.RowIndex].Cells[1].Value.ToString();
            capacityField.Text = dgvRoomType.Rows[e.RowIndex].Cells[2].Value.ToString();
        }
    }
}
