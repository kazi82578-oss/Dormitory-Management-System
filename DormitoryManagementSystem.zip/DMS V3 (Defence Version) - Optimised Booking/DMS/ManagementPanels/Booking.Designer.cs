﻿namespace DMS.ManagementPanels
{
    partial class Booking
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.clearTimer = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvBooking = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtStudentName = new System.Windows.Forms.TextBox();
            this.btnApplyFilters = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnResetFilters = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cbDorm = new System.Windows.Forms.ComboBox();
            this.chbDorm = new System.Windows.Forms.CheckBox();
            this.cbRoomType = new System.Windows.Forms.ComboBox();
            this.dtpLeaseStart = new System.Windows.Forms.DateTimePicker();
            this.dtpLeaseEnd = new System.Windows.Forms.DateTimePicker();
            this.cbStatus = new System.Windows.Forms.ComboBox();
            this.chbName = new System.Windows.Forms.CheckBox();
            this.chbRoomType = new System.Windows.Forms.CheckBox();
            this.chbLeaseStart = new System.Windows.Forms.CheckBox();
            this.chbLeaseEnd = new System.Windows.Forms.CheckBox();
            this.chbStatus = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnReject = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnFoodBooking = new System.Windows.Forms.Button();
            this.btnCollectPayment = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBooking)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // clearTimer
            // 
            this.clearTimer.Interval = 10;
            this.clearTimer.Tick += new System.EventHandler(this.ClearTimer_Tick);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1247, 54);
            this.panel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(538, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Manage Bookings";
            // 
            // dgvBooking
            // 
            this.dgvBooking.AllowUserToAddRows = false;
            this.dgvBooking.AllowUserToDeleteRows = false;
            this.dgvBooking.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBooking.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10});
            this.dgvBooking.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvBooking.Location = new System.Drawing.Point(0, 0);
            this.dgvBooking.Name = "dgvBooking";
            this.dgvBooking.ReadOnly = true;
            this.dgvBooking.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBooking.Size = new System.Drawing.Size(939, 619);
            this.dgvBooking.TabIndex = 0;
            this.dgvBooking.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvBooking_CellClick);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "BookingID";
            this.Column1.HeaderText = "ID";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.DataPropertyName = "Name";
            this.Column2.HeaderText = "Student Name";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.DataPropertyName = "DormName";
            this.Column3.HeaderText = "Dormitory";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.DataPropertyName = "RoomType";
            this.Column4.HeaderText = "Room Type";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "LeaseStart";
            this.Column5.HeaderText = "Lease Start";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 70;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "LeaseEnd";
            this.Column6.HeaderText = "Lease End";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 70;
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "FoodStart";
            this.Column7.HeaderText = "Food Start";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Visible = false;
            this.Column7.Width = 70;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "FoodEnd";
            this.Column8.HeaderText = "Food End";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Visible = false;
            this.Column8.Width = 70;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "Status";
            this.Column9.HeaderText = "Status";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 60;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "TotalBill";
            this.Column10.HeaderText = "Total Bill";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.dgvBooking);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 43);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(941, 621);
            this.panel5.TabIndex = 3;
            // 
            // txtStudentName
            // 
            this.txtStudentName.Location = new System.Drawing.Point(13, 37);
            this.txtStudentName.Name = "txtStudentName";
            this.txtStudentName.Size = new System.Drawing.Size(268, 20);
            this.txtStudentName.TabIndex = 1;
            // 
            // btnApplyFilters
            // 
            this.btnApplyFilters.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApplyFilters.Location = new System.Drawing.Point(3, 3);
            this.btnApplyFilters.Name = "btnApplyFilters";
            this.btnApplyFilters.Size = new System.Drawing.Size(205, 26);
            this.btnApplyFilters.TabIndex = 3;
            this.btnApplyFilters.Text = "Apply Filters";
            this.btnApplyFilters.UseVisualStyleBackColor = true;
            this.btnApplyFilters.Click += new System.EventHandler(this.BtnApplyFilters_Click);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.btnResetFilters);
            this.panel3.Controls.Add(this.btnApplyFilters);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(950, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(294, 34);
            this.panel3.TabIndex = 1;
            // 
            // btnResetFilters
            // 
            this.btnResetFilters.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetFilters.Location = new System.Drawing.Point(214, 3);
            this.btnResetFilters.Name = "btnResetFilters";
            this.btnResetFilters.Size = new System.Drawing.Size(75, 26);
            this.btnResetFilters.TabIndex = 4;
            this.btnResetFilters.Text = "Reset";
            this.btnResetFilters.UseVisualStyleBackColor = true;
            this.btnResetFilters.Click += new System.EventHandler(this.BtnResetFilters_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.tableLayoutPanel2.Controls.Add(this.panel3, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel4, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.panel5, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 63);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1247, 667);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.cbDorm);
            this.panel4.Controls.Add(this.chbDorm);
            this.panel4.Controls.Add(this.txtStudentName);
            this.panel4.Controls.Add(this.cbRoomType);
            this.panel4.Controls.Add(this.dtpLeaseStart);
            this.panel4.Controls.Add(this.dtpLeaseEnd);
            this.panel4.Controls.Add(this.cbStatus);
            this.panel4.Controls.Add(this.chbName);
            this.panel4.Controls.Add(this.chbRoomType);
            this.panel4.Controls.Add(this.chbLeaseStart);
            this.panel4.Controls.Add(this.chbLeaseEnd);
            this.panel4.Controls.Add(this.chbStatus);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(950, 43);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(294, 621);
            this.panel4.TabIndex = 2;
            // 
            // cbDorm
            // 
            this.cbDorm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDorm.FormattingEnabled = true;
            this.cbDorm.Location = new System.Drawing.Point(13, 100);
            this.cbDorm.Name = "cbDorm";
            this.cbDorm.Size = new System.Drawing.Size(268, 21);
            this.cbDorm.TabIndex = 27;
            // 
            // chbDorm
            // 
            this.chbDorm.AutoSize = true;
            this.chbDorm.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chbDorm.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbDorm.Location = new System.Drawing.Point(8, 72);
            this.chbDorm.Name = "chbDorm";
            this.chbDorm.Size = new System.Drawing.Size(109, 25);
            this.chbDorm.TabIndex = 28;
            this.chbDorm.Text = "Dormitory";
            this.chbDorm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chbDorm.UseVisualStyleBackColor = true;
            // 
            // cbRoomType
            // 
            this.cbRoomType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbRoomType.FormattingEnabled = true;
            this.cbRoomType.Location = new System.Drawing.Point(13, 164);
            this.cbRoomType.Name = "cbRoomType";
            this.cbRoomType.Size = new System.Drawing.Size(268, 21);
            this.cbRoomType.TabIndex = 15;
            // 
            // dtpLeaseStart
            // 
            this.dtpLeaseStart.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpLeaseStart.Location = new System.Drawing.Point(13, 226);
            this.dtpLeaseStart.Name = "dtpLeaseStart";
            this.dtpLeaseStart.Size = new System.Drawing.Size(268, 20);
            this.dtpLeaseStart.TabIndex = 16;
            // 
            // dtpLeaseEnd
            // 
            this.dtpLeaseEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpLeaseEnd.Location = new System.Drawing.Point(13, 286);
            this.dtpLeaseEnd.Name = "dtpLeaseEnd";
            this.dtpLeaseEnd.Size = new System.Drawing.Size(268, 20);
            this.dtpLeaseEnd.TabIndex = 17;
            // 
            // cbStatus
            // 
            this.cbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbStatus.FormattingEnabled = true;
            this.cbStatus.Items.AddRange(new object[] {
            "Pending",
            "Confirmed",
            "Cancelled",
            "Rejected"});
            this.cbStatus.Location = new System.Drawing.Point(13, 346);
            this.cbStatus.Name = "cbStatus";
            this.cbStatus.Size = new System.Drawing.Size(268, 21);
            this.cbStatus.TabIndex = 20;
            // 
            // chbName
            // 
            this.chbName.AutoSize = true;
            this.chbName.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chbName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbName.Location = new System.Drawing.Point(8, 9);
            this.chbName.Name = "chbName";
            this.chbName.Size = new System.Drawing.Size(130, 25);
            this.chbName.TabIndex = 25;
            this.chbName.Text = "Search Name";
            this.chbName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chbName.UseVisualStyleBackColor = true;
            // 
            // chbRoomType
            // 
            this.chbRoomType.AutoSize = true;
            this.chbRoomType.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chbRoomType.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbRoomType.Location = new System.Drawing.Point(8, 136);
            this.chbRoomType.Name = "chbRoomType";
            this.chbRoomType.Size = new System.Drawing.Size(114, 25);
            this.chbRoomType.TabIndex = 24;
            this.chbRoomType.Text = "Room Type";
            this.chbRoomType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chbRoomType.UseVisualStyleBackColor = true;
            // 
            // chbLeaseStart
            // 
            this.chbLeaseStart.AutoSize = true;
            this.chbLeaseStart.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chbLeaseStart.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbLeaseStart.Location = new System.Drawing.Point(8, 195);
            this.chbLeaseStart.Name = "chbLeaseStart";
            this.chbLeaseStart.Size = new System.Drawing.Size(111, 25);
            this.chbLeaseStart.TabIndex = 23;
            this.chbLeaseStart.Text = "Lease Start";
            this.chbLeaseStart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chbLeaseStart.UseVisualStyleBackColor = true;
            // 
            // chbLeaseEnd
            // 
            this.chbLeaseEnd.AutoSize = true;
            this.chbLeaseEnd.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chbLeaseEnd.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbLeaseEnd.Location = new System.Drawing.Point(8, 257);
            this.chbLeaseEnd.Name = "chbLeaseEnd";
            this.chbLeaseEnd.Size = new System.Drawing.Size(104, 25);
            this.chbLeaseEnd.TabIndex = 22;
            this.chbLeaseEnd.Text = "Lease End";
            this.chbLeaseEnd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chbLeaseEnd.UseVisualStyleBackColor = true;
            // 
            // chbStatus
            // 
            this.chbStatus.AutoSize = true;
            this.chbStatus.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chbStatus.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbStatus.Location = new System.Drawing.Point(8, 318);
            this.chbStatus.Name = "chbStatus";
            this.chbStatus.Size = new System.Drawing.Size(76, 25);
            this.chbStatus.TabIndex = 21;
            this.chbStatus.Text = "Status";
            this.chbStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chbStatus.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.66666F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel6, 1, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(941, 34);
            this.tableLayoutPanel3.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnReject);
            this.panel2.Controls.Add(this.btnConfirm);
            this.panel2.Controls.Add(this.btnDelete);
            this.panel2.Controls.Add(this.btnRefresh);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(619, 26);
            this.panel2.TabIndex = 0;
            // 
            // btnReject
            // 
            this.btnReject.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReject.Location = new System.Drawing.Point(494, 0);
            this.btnReject.Name = "btnReject";
            this.btnReject.Size = new System.Drawing.Size(122, 26);
            this.btnReject.TabIndex = 9;
            this.btnReject.Text = "Reject Booking";
            this.btnReject.UseVisualStyleBackColor = true;
            this.btnReject.Click += new System.EventHandler(this.BtnReject_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm.Location = new System.Drawing.Point(366, 0);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(122, 26);
            this.btnConfirm.TabIndex = 8;
            this.btnConfirm.Text = "Confirm Booking";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.BtnConfirm_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(84, 0);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 26);
            this.btnDelete.TabIndex = 6;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.Location = new System.Drawing.Point(3, 0);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 26);
            this.btnRefresh.TabIndex = 5;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.BtnRefresh_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btnFoodBooking);
            this.panel6.Controls.Add(this.btnCollectPayment);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(630, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(307, 26);
            this.panel6.TabIndex = 1;
            // 
            // btnFoodBooking
            // 
            this.btnFoodBooking.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFoodBooking.Location = new System.Drawing.Point(154, 0);
            this.btnFoodBooking.Name = "btnFoodBooking";
            this.btnFoodBooking.Size = new System.Drawing.Size(150, 26);
            this.btnFoodBooking.TabIndex = 7;
            this.btnFoodBooking.Text = "Food Booking";
            this.btnFoodBooking.UseVisualStyleBackColor = true;
            this.btnFoodBooking.Click += new System.EventHandler(this.BtnFoodBooking_Click);
            // 
            // btnCollectPayment
            // 
            this.btnCollectPayment.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCollectPayment.Location = new System.Drawing.Point(3, 0);
            this.btnCollectPayment.Name = "btnCollectPayment";
            this.btnCollectPayment.Size = new System.Drawing.Size(150, 26);
            this.btnCollectPayment.TabIndex = 6;
            this.btnCollectPayment.Text = "Collect Payment";
            this.btnCollectPayment.UseVisualStyleBackColor = true;
            this.btnCollectPayment.Click += new System.EventHandler(this.BtnCollectPayment_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1253, 733);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // Booking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Booking";
            this.Size = new System.Drawing.Size(1253, 733);
            this.Load += new System.EventHandler(this.Booking_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBooking)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer clearTimer;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvBooking;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtStudentName;
        private System.Windows.Forms.Button btnApplyFilters;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnResetFilters;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btnFoodBooking;
        private System.Windows.Forms.Button btnCollectPayment;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.ComboBox cbRoomType;
        private System.Windows.Forms.DateTimePicker dtpLeaseStart;
        private System.Windows.Forms.DateTimePicker dtpLeaseEnd;
        private System.Windows.Forms.ComboBox cbStatus;
        private System.Windows.Forms.CheckBox chbName;
        private System.Windows.Forms.CheckBox chbRoomType;
        private System.Windows.Forms.CheckBox chbLeaseStart;
        private System.Windows.Forms.CheckBox chbLeaseEnd;
        private System.Windows.Forms.CheckBox chbStatus;
        private System.Windows.Forms.ComboBox cbDorm;
        private System.Windows.Forms.CheckBox chbDorm;
        private System.Windows.Forms.Button btnReject;
        private System.Windows.Forms.Button btnConfirm;
    }
}
