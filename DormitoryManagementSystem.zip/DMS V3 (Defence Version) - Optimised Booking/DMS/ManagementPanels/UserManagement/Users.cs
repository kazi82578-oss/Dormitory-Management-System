﻿using DMS.ManagementPanels.UserManagement.EditorViews;
using DMS.ManagementPanels.UserManagement.EntryPanels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS.ManagementPanels
{
    public partial class Users : UserControl
    {
        GeneralEditorView generalEditorView;
        WardenEditorView wardenEditorView;
        StudentEditorView studentEditorView;

        public Users()
        {
            InitializeComponent();

            generalEditorView = new GeneralEditorView();
            generalEditorView.Dock = DockStyle.Fill;

            wardenEditorView = new WardenEditorView();
            wardenEditorView.Dock = DockStyle.Fill;

            studentEditorView = new StudentEditorView();
            studentEditorView.Dock = DockStyle.Fill;
        }

        // <---------- EVENT HANDLERS ---------->

        private void Users_Load(object sender, EventArgs e) // Load event to initialize data when the UserControl is loaded
        {
            // Add the GeneralEditorView to the panel
            panelEditorView.Controls.Add(generalEditorView);

            this.LoadData();
            clearTimer.Start();
            switchTimer.Start();
        }

        private void BtnNew_Click(object sender, EventArgs e) // New button to clear input fields for adding a new user
        {
            this.ClearFields();
        }

        private void BtnDelete_Click(object sender, EventArgs e) // Delete button to remove the selected user from the database
        {
            if (generalEditorView.IsNewMode)
            {
                MessageBox.Show("Please select a user to delete.");
                return;
            }

            if (!generalEditorView.SufficientCRUDPermission(dgvUserInfo.CurrentRow.Cells[3].Value.ToString())) return;

            var result = MessageBox.Show($"Are you sure you want to delete \"{generalEditorView.CurrentName}\"?", "Confirm Delete", MessageBoxButtons.YesNo);
            if (result == DialogResult.No) return;

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"DELETE FROM Users WHERE UserID = {generalEditorView.CurrentID}";
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Delete Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();

            MessageBox.Show("User deleted successfully.", "Delete Successful");
        }

        private void BtnRefresh_Click(object sender, EventArgs e) // Refresh button to reload data from the database
        {
            this.LoadData();
            this.ClearFields();
        }

        private void BtnSave_Click(object sender, EventArgs e) // Save button to insert or update user data in the database
        {
            if (generalEditorView.CurrentID == "Auto Generated")
            {
                this.InsertLogic();
            }
            else
            {
                this.UpdateLogic();
            }
        }

        private void BtnEditPass_Click(object sender, EventArgs e) // Edit Password button to enable password fields for editing
        {
            if (generalEditorView.CurrentID == "Auto Generated")
            {
                return;
            }

            generalEditorView.TogglePasswordEditability();
        }

        private void BtnSwitchPage_Click(object sender, EventArgs e)
        {
            panelEditorView.Controls.Clear();

            if (btnSwitchPage.Text == "Back to General") // Switch back to GeneralEditorView
            {
                panelEditorView.Controls.Add(generalEditorView);
                btnSwitchPage.Text = "Next";
                return;
            }

            if (generalEditorView.CurrentRole == "Warden") // Switch to role-specific editor view based on the selected role
            {
                panelEditorView.Controls.Add(wardenEditorView);
            }
            else if (generalEditorView.CurrentRole == "Student")
            {
                panelEditorView.Controls.Add(studentEditorView);
            }
            else // This shouldn't be possible, but just in case
            {
                MessageBox.Show("Unexpected error occured.", "Switch Page Not Available");
                return;
            }

            btnSwitchPage.Text = "Back to General";
        }

        private void DgvUserInfo_CellClick(object sender, DataGridViewCellEventArgs e) // Cell click event to populate input fields with the selected user's data
        {
            if (e.RowIndex < 0) return;

            string uID = dgvUserInfo.Rows[e.RowIndex].Cells[0].Value.ToString();
            string uName = dgvUserInfo.Rows[e.RowIndex].Cells[1].Value.ToString();
            string uEmail = dgvUserInfo.Rows[e.RowIndex].Cells[2].Value.ToString();
            string uRole = dgvUserInfo.Rows[e.RowIndex].Cells[3].Value.ToString();
            string uGender = dgvUserInfo.Rows[e.RowIndex].Cells[4].Value.ToString();
            string uContactNo = dgvUserInfo.Rows[e.RowIndex].Cells[5].Value.ToString();
            DateTime uDOB = Convert.ToDateTime(dgvUserInfo.Rows[e.RowIndex].Cells[6].Value);
            string uPass = dgvUserInfo.Rows[e.RowIndex].Cells[7].Value.ToString();

            generalEditorView.PopulateFields(uID, uName, uEmail, uPass, uRole, uGender, uContactNo, uDOB);
            generalEditorView.EditMode();

            switchTimer.Stop();
        }

        private void ClearTimer_Tick(object sender, EventArgs e) // Timer to clear selection in the DataGridView after a short delay
        {
            dgvUserInfo.ClearSelection();
            clearTimer.Stop();
        }

        private void SwitchTimer_Tick(object sender, EventArgs e) // Timer to manage UI state based on current mode and role
        {
            if (generalEditorView.CurrentID != "Auto Generated") // If not in "New" mode, stop the timer. This is backup, just in case cell click event doesn't stop it.
            {
                switchTimer.Stop();
            }

            if (generalEditorView.CurrentRole == "Warden" || generalEditorView.CurrentRole == "Student") // Enable switch page button for Warden and Student roles
            {
                btnSwitchPage.Enabled = true;
            }
            else // Disable switch page button for other roles
            {
                btnSwitchPage.Enabled = false;
            }
        }

        // <---------- HELPER METHODS ---------->

        private void LoadData() // Load data from the database and display it in the DataGridView
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "SELECT * FROM Users ORDER BY UserID; SELECT * FROM Dormitory ORDER BY DormID";

                var adp = new SqlDataAdapter(cmd);
                var ds = new DataSet();
                adp.Fill(ds);
                con.Close();

                dgvUserInfo.AutoGenerateColumns = false;
                dgvUserInfo.DataSource = ds.Tables[0];
                dgvUserInfo.Refresh();

                wardenEditorView.LoadData(ds.Tables[1]); // Load dormitory data into WardenEditorView ComboBox
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Load Failed");
                return;
            }
        }

        private void ClearFields() // Clear input fields and reset the form state
        {
            switchTimer.Start();

            generalEditorView.ClearFields();
            wardenEditorView.ClearFields();
            studentEditorView.ClearFields();

            panelEditorView.Controls.Clear();
            panelEditorView.Controls.Add(generalEditorView);
            btnSwitchPage.Text = "Next";

            dgvUserInfo.ClearSelection();
        }

        private void UpdateLogic() // Logic to update an existing user's data in the database
        {
            if (!generalEditorView.ValidateFields(dgvUserInfo)) return;

            if (!generalEditorView.SufficientCRUDPermission(dgvUserInfo.CurrentRow.Cells[3].Value.ToString())) return;

            string uID, uName, uEmail, uPass, uRole, uGender, uContactNo;
            DateTime uDOB;

            generalEditorView.GetFieldValues(out uID, out uName, out uEmail, out uPass, out uRole, out uGender, out uContactNo, out uDOB);

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"UPDATE Users SET Name = '{uName}', Email = '{uEmail}', Password = '{uPass}', Gender = '{uGender}', ContactNo = '{uContactNo}', DateOfBirth = '{uDOB.ToString("yyyy/MM/dd")}' WHERE UserID = {uID}";
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Save Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();

            MessageBox.Show($"\"{uRole}\" saved successfully.", "Save Successful");
        }

        private void InsertLogic()
        {
            if (!generalEditorView.ValidateFields(dgvUserInfo)) return;
            if (!generalEditorView.SufficientCRUDPermission(generalEditorView.CurrentRole)) return;


            // Declare all necessary variables

            string uName, uEmail, uPass, uRole, uGender, uContactNo; // General fields
            DateTime uDOB; // General field

            int wDorm; // Warden-specific field
            string wShift; // Warden-specific field
            DateTime wJoiningDate; // Warden-specific field
            double wSalary; // Warden-specific field

            string sInstituteID, sDept, sProgram; // Student-specific fields
            byte sYear; // Student-specific field


            generalEditorView.GetFieldValues(out uName, out uEmail, out uPass, out uRole, out uGender, out uContactNo, out uDOB); // Get general field values

            string mainQuery = $"INSERT INTO Users VALUES('{uName}', '{uEmail}', '{uPass}', '{uRole}', '{uGender}', '{uContactNo}', '{uDOB.ToString("yyyy-MM-dd")}');"; // Main insert query for Users table
            string roleSpecificQuery = ""; // Role-specific insert query, if applicable
            string fullQuery = "";


            if (generalEditorView.CurrentRole == "Warden")
            {
                if (!wardenEditorView.ValidateFields(uDOB)) return; // Pass DOB to check joining date validation
                wardenEditorView.GetFieldValues(out wDorm, out wShift, out wJoiningDate, out wSalary); // Get Warden-specific field values
                roleSpecificQuery = $"INSERT INTO WardenInfo VALUES(@id, {wDorm}, '{wShift}', '{wJoiningDate.ToString("yyyy/MM/dd")}', {wSalary});";
            }
            else if (generalEditorView.CurrentRole == "Student")
            {
                if (!studentEditorView.ValidateFields()) return;
                studentEditorView.GetFieldValues(out sInstituteID, out sDept, out sProgram, out sYear); // Get Student-specific field values
                roleSpecificQuery = $"INSERT INTO StudentInfo VALUES(@id, '{sInstituteID}', '{sDept}', '{sProgram}', {sYear});";
            } // Admin creation doesn't have any extra fields to validate


            if (string.IsNullOrWhiteSpace(roleSpecificQuery)) // No role-specific query, just insert into Users table
            {
                fullQuery = mainQuery;
            }
            else // Role-specific query exists, need to get the new UserID and use it in the role-specific insert
            {
                fullQuery = "DECLARE @id int;" + mainQuery + "SET @id = CAST(SCOPE_IDENTITY() AS int);" + roleSpecificQuery;
            }


            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = fullQuery;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Save Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();

            MessageBox.Show($"\"{uRole}\" saved successfully.", "Save Successful");
        }
    }
}
