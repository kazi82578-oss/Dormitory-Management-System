﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS.ManagementPanels.UserManagement.EditorViews
{
    public partial class StudentEditorView : UserControl
    {
        public StudentEditorView()
        {
            InitializeComponent();
        }

        // <---------- PARENT CONTROL EVENT HANDLER HELPERS ---------->

        public bool ValidateFields() // Validate input fields before saving a student record
        {
            string instituteID = txtInstituteID.Text;
            sbyte deptIndex = (sbyte)cbDepartment.SelectedIndex;
            sbyte programIndex = (sbyte)cbProgram.SelectedIndex;
            sbyte yearOfStudyIndex = (sbyte)cbYearOfStudy.SelectedIndex;

            if (string.IsNullOrWhiteSpace(instituteID)) // Institute ID is empty
            {
                MessageBox.Show("Institute ID cannot be empty.", "Validation Error");
                return false;
            }

            if (instituteID.Length < 1 || instituteID.Length > 10) // Institute ID length is invalid
            {
                MessageBox.Show("Institute ID must be between 1 and 10 characters long.", "Validation Error");
                return false;
            }

            if (deptIndex < 0) // No department selected
            {
                MessageBox.Show("Please select a department.", "Validation Error");
                return false;
            }

            if (programIndex < 0) // No program selected
            {
                MessageBox.Show("Please select a program.", "Validation Error");
                return false;
            }

            if (yearOfStudyIndex < 0) // No year of study selected
            {
                MessageBox.Show("Please select a year of study.", "Validation Error");
                return false;
            }

            return true; // All validations passed
        }

        public void GetFieldValues(out string sInstituteID, out string sDept, out string sProgram, out byte sYear) // Retrieve input field values for saving a student record
        {
            sInstituteID = txtInstituteID.Text;
            sDept = cbDepartment.SelectedItem.ToString();
            sProgram = cbProgram.SelectedItem.ToString();
            sYear = (byte) (cbYearOfStudy.SelectedIndex + 1);
        }

        public void ClearFields() // Clear input fields and reset the form state
        {
            txtInstituteID.Text = "";
            cbDepartment.SelectedIndex = -1;
            cbProgram.SelectedIndex = -1;
            cbYearOfStudy.SelectedIndex = -1;
        }
    }
}
