﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS.ManagementPanels.UserManagement.EditorViews
{
    public partial class WardenEditorView : UserControl
    {
        public WardenEditorView()
        {
            InitializeComponent();
        }

        // <---------- PARENT CONTROL EVENT HANDLER HELPERS ---------->

        public bool ValidateFields(DateTime dob) // Validate input fields before saving a warden record
        {
            sbyte dormIndex = (sbyte)cbDormitory.SelectedIndex;
            sbyte shiftIndex = (sbyte)cbShift.SelectedIndex;
            DateTime joiningDate = dtpJoiningDate.Value;
            string salaryText = txtSalary.Text;
            double salary;

            if (dormIndex < 0) // No dormitory selected
            {
                MessageBox.Show("Please select a dormitory.", "Validation Error");
                return false;
            }

            if (shiftIndex < 0) // No shift selected
            {
                MessageBox.Show("Please select a shift.", "Validation Error");
                return false;
            }

            if (joiningDate > DateTime.Now) // Joining date is in the future
            {
                MessageBox.Show("Joining date cannot be in the future.", "Validation Error");
                return false;
            }

            if (joiningDate < dob) // Joining date cannot be earlier than DOB
            {
                MessageBox.Show("Joining Date cannot be earlier than Date of Birth.", "Validation Error");
                return false;
            }

            try // Invalid salary input
            {
                salary = double.Parse(salaryText);
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter a valid salary amount.", "Validation Error");
                return false;
            }

            if (salary < 0 || salary > 999999.99) // Salary out of range
            {
                MessageBox.Show("Salary must be between 0 and 999999.99.", "Validation Error");
                return false;
            }

            return true;
        }

        public void GetFieldValues(out int wDormID, out string wShift, out DateTime wJoiningDate, out double wSalary) // Retrieve input field values
        {
            wDormID = (int) cbDormitory.SelectedValue;
            wShift = cbShift.SelectedItem.ToString();
            wJoiningDate = dtpJoiningDate.Value;
            wSalary = double.Parse(txtSalary.Text.Trim());
        }

        public void ClearFields() // Clear input fields and reset the form state
        {
            cbDormitory.SelectedIndex = -1;
            cbShift.SelectedIndex = -1;
            dtpJoiningDate.Value = DateTime.Now;
            txtSalary.Text = "";
        }

        public void LoadData(DataTable dt) // Load dormitory data into the dormitory ComboBox
        {
            //try
            //{
            //    var con = new SqlConnection();
            //    con.ConnectionString = ApplicationHelper.ConnectionString;
            //    con.Open();

            //    var cmd = new SqlCommand();
            //    cmd.Connection = con;
            //    cmd.CommandText = "SELECT * FROM Dormitory ORDER BY DormID";

            //    var adp = new SqlDataAdapter(cmd);
            //    var dt = new DataTable();
            //    adp.Fill(dt);
            //    con.Close();

            //    cbDormitory.DataSource = dt;
            //    cbDormitory.DisplayMember = "DormName";
            //    cbDormitory.ValueMember = "DormID";
            //    cbDormitory.SelectedIndex = -1; // No selection by default
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.ToString(), "Load Failed");
            //    return;
            //}

            cbDormitory.DataSource = dt;
            cbDormitory.DisplayMember = "DormName";
            cbDormitory.ValueMember = "DormID";
            cbDormitory.SelectedIndex = -1; // No selection by default
        }
    }
}
