﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS.ManagementPanels.UserManagement.EntryPanels
{
    public partial class GeneralEditorView : UserControl
    {
        public GeneralEditorView()
        {
            InitializeComponent();
        }

        // <---------- PARENT CONTROL EVENT HANDLER HELPERS ---------->

        public void PopulateFields(string uID, string uName, string uEmail, string uPass, string uRole, string uGender, string uContactNo, DateTime uDOB) // Populate input fields with the selected user's data
        {
            txtID.Text = uID;
            txtName.Text = uName;
            txtEmail.Text = uEmail;
            txtPass.Text = uPass;
            txtConfPass.Text = uPass;
            cbRole.SelectedItem = uRole;
            cbGender.SelectedItem = uGender;
            txtContactNo.Text = uContactNo;
            dtpDOB.Value = uDOB;
        }

        public bool SufficientCRUDPermission(string uRole) // Check if the current user has permission to create, update or delete the selected user
        {
            // uRole is the role of the user being created, updated or deleted

            if (ApplicationHelper.CurrentUserRole != "SuperAdmin" && ApplicationHelper.CurrentUserRole != "Admin") // This shouldn't be possible, but just in case
            {
                MessageBox.Show("You do not have permission to create, update or delete any user.\nP.S. You shouldn't be on this page.", "Create/Update/Delete Not Allowed");
                return false;
            }

            if (uRole == "SuperAdmin") // Prevent creation, update or deletion of SuperAdmin users
            {
                MessageBox.Show("You cannot create, update or delete a SuperAdmin user.", "Create/Update/Delete Not Allowed");
                return false;
            }

            if (uRole == "Admin" && ApplicationHelper.CurrentUserRole != "SuperAdmin") // Only SuperAdmin can create, update or delete Admin users
            {
                MessageBox.Show("Only SuperAdmin users can create, update or delete Admin users.", "Create/Update/Delete Not Allowed");
                return false;
            }

            return true; // Sufficient permission to create, update or delete the user
        }

        public void ClearFields() // Clear input fields and reset the form state
        {
            txtID.Text = "Auto Generated";
            txtName.Text = "";
            txtEmail.Text = "";
            txtPass.Text = "";
            txtConfPass.Text = "";
            cbRole.SelectedIndex = -1;
            cbGender.SelectedIndex = -1;
            txtContactNo.Text = "";
            dtpDOB.Value = DateTime.Now;

            txtEmail.ReadOnly = false;
            txtPass.ReadOnly = false;
            txtConfPass.ReadOnly = false;
            cbRole.Enabled = true;
        }

        public void EditMode() // Set the form to edit mode
        {
            txtEmail.ReadOnly = true;
            txtPass.ReadOnly = true;
            txtConfPass.ReadOnly = true;
            cbRole.Enabled = false;
        }

        public void TogglePasswordEditability() // Toggle the read-only state of the password fields
        {
            txtPass.ReadOnly = !txtPass.ReadOnly;
            txtConfPass.ReadOnly = !txtConfPass.ReadOnly;
        }

        public bool ValidateFields(DataGridView dgvUsers) // Validate input fields before saving
        {
            string uName = txtName.Text.Trim();
            string uEmail = txtEmail.Text.Trim();
            string uPass = txtPass.Text;
            string uConfPass = txtConfPass.Text;
            sbyte uRoleIndex = (sbyte)cbRole.SelectedIndex;
            sbyte uGenderIndex = (sbyte)cbGender.SelectedIndex;
            string uContactNo = txtContactNo.Text.Trim();
            DateTime uDOB = dtpDOB.Value;

            if (string.IsNullOrWhiteSpace(uName)) // Validate that name is not empty
            {
                MessageBox.Show("Please enter a valid name.", "Validation Error");
                return false;
            }

            if (uName.Length < 1 || uName.Length > 128) // Validate that name length is within acceptable range
            {
                MessageBox.Show("Name must be between 1 and 128 characters.", "Validation Error");
                return false;
            }

            if (string.IsNullOrWhiteSpace(uEmail)) // Validate that email is not empty
            {
                MessageBox.Show("Please enter a valid email.", "Validation Error");
                return false;
            }

            if (uEmail.Length < 5 || uEmail.Length > 256 || !uEmail.Contains("@") || !uEmail.Contains(".")) // Basic email format validation
            {
                MessageBox.Show("Please enter a valid email address.", "Validation Error");
                return false;
            }

            if (txtID.Text == "Auto Generated") // Only check for duplicates when adding a new user
            {
                for (int i = 0; i < dgvUsers.Rows.Count; i++)
                {
                    if (uEmail.Equals(dgvUsers.Rows[i].Cells[2].Value.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show("Email already exists. Please enter a different email.", "Validation Error");
                        return false;
                    }
                }
            }

            if (uPass != uConfPass) // Validate that password and confirm password match
            {
                MessageBox.Show("Password and Confirm Password do not match.", "Validation Error");
                return false;
            }

            if (uPass.Length < 7 || uPass.Length > 256) // Validate that password length is within acceptable range
            {
                MessageBox.Show("Password must be between 7 and 256 characters.", "Validation Error");
                return false;
            }

            if (uRoleIndex < 0) // Check if a role is selected
            {
                MessageBox.Show("Please select a role.", "Validation Error");
                return false;
            }

            if (uGenderIndex < 0) // Check if a gender is selected
            {
                MessageBox.Show("Please select a gender.", "Validation Error");
                return false;
            }

            if (string.IsNullOrWhiteSpace(uContactNo)) // Validate that contact number is not empty
            {
                MessageBox.Show("Please enter a valid contact number.", "Validation Error");
                return false;
            }

            if (uContactNo.Length < 7 || uContactNo.Length > 14) // Validate that contact number length is within acceptable range
            {
                MessageBox.Show("Contact number must be between 7 and 14 characters.", "Validation Error");
                return false;
            }

            if (uDOB >= DateTime.Now) // Validate that date of birth is in the past
            {
                MessageBox.Show("Please enter a valid date of birth.", "Validation Error");
                return false;
            }

            return true; // All validations passed
        }

        public void GetFieldValues(out string uName, out string uEmail, out string uPass, out string uRole, out string uGender, out string uContactNo, out DateTime uDOB) // Fetch data from input fields, for insert logic
        {
            uName = txtName.Text.Trim();
            uEmail = txtEmail.Text.Trim();
            uPass = txtPass.Text;
            uRole = cbRole.SelectedItem.ToString();
            uGender = cbGender.SelectedItem.ToString();
            uContactNo = txtContactNo.Text.Trim();
            uDOB = dtpDOB.Value;
        }

        public void GetFieldValues(out string uID, out string uName, out string uEmail, out string uPass, out string uRole, out string uGender, out string uContactNo, out DateTime uDOB) // Fetch data from input fields, for update logic
        {
            uID = txtID.Text;
            GetFieldValues(out uName, out uEmail, out uPass, out uRole, out uGender, out uContactNo, out uDOB);
        }

        public bool IsNewMode // Check if the form is in "new" mode based on the ID field
        {
            get { return txtID.Text == "Auto Generated"; }
        }

        public string CurrentID // Get the current ID from the ID input field
        {
            get { return txtID.Text; }
        }

        public string CurrentName // Get the current name from the name input field
        {
            get { return txtName.Text; }
        }

        public string CurrentRole // Get the current role from the role combo box
        {
            get { return cbRole.SelectedItem == null ? "" : cbRole.SelectedItem.ToString(); }
        }
    }
}
