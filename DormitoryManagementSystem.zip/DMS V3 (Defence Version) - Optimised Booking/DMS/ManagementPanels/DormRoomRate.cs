﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS.ManagementPanels
{
    public partial class DormRoomRate : UserControl
    {
        public DormRoomRate()
        {
            InitializeComponent();
        }

        // <--------------------- Event Handlers ----------------->

        private void DormRoomRate_Load(object sender, EventArgs e) // Load event to initialize data when the UserControl is loaded
        {
            this.LoadData();
            clearTimer.Start();
        }

        private void BtnNew_Click(object sender, EventArgs e) // New button to clear input fields for adding a new room type
        {
            this.ClearFields();
        }

        private void BtnDelete_Click(object sender, EventArgs e) // Delete button to remove the selected entry from the database
        {
            if (txtID.Text == "Auto Generated")
            {
                MessageBox.Show("Please select an entry to delete.");
                return;
            }

            var result = MessageBox.Show($"Are you sure you want to delete?", "Confirm Delete", MessageBoxButtons.YesNo);
            if (result == DialogResult.No) return;

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"DELETE FROM DormRoomRate WHERE RateID = {txtID.Text}";
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Delete Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();

            MessageBox.Show("Entry deleted successfully.", "Delete Successful");
        }

        private void BtnRefresh_Click(object sender, EventArgs e) // Refresh button to reload data from the database
        {
            this.LoadData();
            this.ClearFields();
        }

        private void BtnSave_Click(object sender, EventArgs e) // Refresh button to reload data from the database
        {
            if (!this.ValidateFields()) return;

            int dormID = (int) cbDorm.SelectedValue;
            int roomTypeID = (int) cbRoomType.SelectedValue;
            double monthlyRent = double.Parse(txtMonthlyRent.Text.Trim());

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;

                if (txtID.Text == "Auto Generated") // Insert new dormitory
                {
                    cmd.CommandText = $"INSERT INTO DormRoomRate VALUES({dormID}, {roomTypeID}, {monthlyRent})";
                }
                else // Update existing dormitory
                {
                    cmd.CommandText = $"UPDATE DormRoomRate SET DormID = {dormID}, RoomTypeID = {roomTypeID}, MonthlyRent = {monthlyRent} WHERE RateID = {txtID.Text}";
                }

                cmd.ExecuteNonQuery();
                con.Close();

            } catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Save Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();

            MessageBox.Show("Entry saved successfully.", "Save Successful");
        }

        private void DgvRoomRate_CellClick(object sender, DataGridViewCellEventArgs e) // Handle cell click event to populate input fields with selected row data
        {
            if (e.RowIndex < 0) return;

            txtID.Text = dgvRoomRate.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtMonthlyRent.Text = dgvRoomRate.Rows[e.RowIndex].Cells[3].Value.ToString();
            cbDorm.SelectedValue = dgvRoomRate.Rows[e.RowIndex].Cells[4].Value;
            cbRoomType.SelectedValue = dgvRoomRate.Rows[e.RowIndex].Cells[5].Value;
        }

        private void ClearTimer_Tick(object sender, EventArgs e) // Timer to clear selection in DataGridView after a short interval
        {
            dgvRoomRate.ClearSelection();
            clearTimer.Stop();
        }

        // <--------------------- Internal Helper Methods ----------------->

        private void LoadData() // Load data from the database and display it in the DataGridView
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "SELECT DRR.RateID, D.DormName, RT.RoomType, DRR.MonthlyRent, DRR.DormID, DRR.RoomTypeID FROM DormRoomRate AS DRR INNER JOIN Dormitory AS D ON D.DormID = DRR.DormID INNER JOIN RoomType AS RT ON RT.RoomTypeID = DRR.RoomTypeID ORDER BY DRR.RateID; SELECT DormID, DormName FROM Dormitory ORDER BY DormID; SELECT RoomTypeID, RoomType FROM RoomType ORDER BY RoomTypeID;";

                var adp = new SqlDataAdapter(cmd);
                var ds = new DataSet();
                adp.Fill(ds);
                con.Close();

                dgvRoomRate.AutoGenerateColumns = false;
                dgvRoomRate.DataSource = ds.Tables[0];
                dgvRoomRate.Refresh();

                cbDorm.DataSource = ds.Tables[1];
                cbDorm.DisplayMember = "DormName";
                cbDorm.ValueMember = "DormID";
                cbDorm.SelectedIndex = -1;

                cbRoomType.DataSource = ds.Tables[2];
                cbRoomType.DisplayMember = "RoomType";
                cbRoomType.ValueMember = "RoomTypeID";
                cbRoomType.SelectedIndex = -1;
            } catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Load Failed");
                return;
            }
        }

        private void ClearFields() // Clear input fields and reset the form state
        {
            txtID.Text = "Auto Generated";
            cbDorm.SelectedIndex = -1;
            cbRoomType.SelectedIndex = -1;
            txtMonthlyRent.Text = "";
            dgvRoomRate.ClearSelection();
        }

        private bool ValidateFields() // Validate input fields before saving to the database
        {
            int dormIndex = cbDorm.SelectedIndex;
            int roomTypeIndex = cbRoomType.SelectedIndex;
            string monthlyRentText = txtMonthlyRent.Text.Trim();
            double monthlyRent;

            if (dormIndex < 0) // Check if dormitory is selected
            {
                MessageBox.Show("Please select a dormitory.", "Validation Error");
                return false;
            }

            if (roomTypeIndex < 0) // Check if room type is selected
            {
                MessageBox.Show("Please select a room type.", "Validation Error");
                return false;
            }

            if (txtID.Text == "Auto Generated") // Only check for duplicates when adding a new room rate
            {
                int dormID = (int) cbDorm.SelectedValue;
                int roomID = (int)cbRoomType.SelectedValue;

                for (int i = 0; i < dgvRoomRate.Rows.Count; i++)
                {
                    if (((int) dgvRoomRate.Rows[i].Cells[4].Value == dormID) && ((int) dgvRoomRate.Rows[i].Cells[5].Value == roomID))
                    {
                        MessageBox.Show("This dormitory already has a rate for the selected room type. Please choose a different combination.", "Validation Error");
                        return false;
                    }
                }
            }

            try // Validate that monthly rent is a valid number
            {
                monthlyRent = double.Parse(monthlyRentText);
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter a valid monthly rent.", "Validation Error");
                return false;
            }

            if (monthlyRent < 1 || monthlyRent > 999999.99) // Validate that monthly rent is within acceptable range
            {
                MessageBox.Show("Monthly rent must be between 1 and 999,999.99.", "Validation Error");
                return false;
            }

            return true; // All validations passed
        }
    }
}
