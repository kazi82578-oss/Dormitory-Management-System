﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace DMS.ManagementPanels
{
    public partial class Payment : Form
    {
        private int bookingID;
        private double totalBill, amountDue;

        public Payment(int bookingID, double totalBill)
        {
            InitializeComponent();
            this.bookingID = bookingID;
            this.totalBill = totalBill;
        }

        // <--------------------- Event Handlers ----------------->

        private void Payment_Load(object sender, EventArgs e) // Load event to initialize data when the UserControl is loaded
        {
            this.LoadData();
            txtBookingID.Text = this.bookingID.ToString();
            this.CalculateDue();
            clearTimer.Start();
        }

        private void BtnNew_Click(object sender, EventArgs e) // New button to clear input fields for adding a new payment
        {
            this.ClearFields();
        }

        private void BtnDelete_Click(object sender, EventArgs e) // Delete button event handler to remove a selected payment from the database
        {
            if (txtID.Text == "Auto Generated")
            {
                MessageBox.Show("Please select a payment entry to delete.");
                return;
            }

            var result = MessageBox.Show($"Are you sure you want to delete the payment entry?", "Confirm Delete", MessageBoxButtons.YesNo);
            if (result == DialogResult.No) return;

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"DELETE FROM Payment WHERE PaymentID = {txtID.Text}";
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Delete Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();

            MessageBox.Show("Payment entry deleted successfully.", "Delete Successful");
        }

        private void BtnRefresh_Click(object sender, EventArgs e) // Refresh button to reload data from the database
        {
            this.LoadData();
            this.ClearFields();
        }

        private void BtnSave_Click(object sender, EventArgs e) // Save button to insert or update payment data in the database
        {

            if (!this.ValidateFields()) return;

            int paymentMethodID = (int) cbMethod.SelectedValue;
            int bookingID = int.Parse(txtBookingID.Text);
            double paymentAmount = double.Parse(txtAmount.Text);
            DateTime paymentDate = dtpDate.Value;
            string reference = txtReference.Text;

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;

                if (txtID.Text == "Auto Generated") // Insert new payment entry
                {
                    cmd.CommandText = $"INSERT INTO Payment VALUES({bookingID}, {paymentMethodID}, {paymentAmount}, '{paymentDate.ToString("yyyy-MM-dd")}', '{reference}')";
                }
                else // Update existing payment entry
                {
                    cmd.CommandText = $"UPDATE Payment SET MethodID = {paymentMethodID}, Amount = {paymentAmount}, PaidAt = '{paymentDate.ToString("yyyy-MM-dd")}', Reference = '{reference}' WHERE PaymentID = {txtID.Text}";
                }

                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Save Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();

            MessageBox.Show("Payment entry saved successfully.", "Save Successful");
        }

        private void DgvPayment_CellClick(object sender, DataGridViewCellEventArgs e) // Cell click event to populate input fields with selected row data
        {
            if (e.RowIndex < 0) return;

            txtID.Text = dgvPayment.Rows[e.RowIndex].Cells[0].Value.ToString();
            cbMethod.SelectedValue = dgvPayment.Rows[e.RowIndex].Cells[5].Value;
            txtAmount.Text = dgvPayment.Rows[e.RowIndex].Cells[2].Value.ToString();
            dtpDate.Value = Convert.ToDateTime(dgvPayment.Rows[e.RowIndex].Cells[3].Value);
            txtReference.Text = dgvPayment.Rows[e.RowIndex].Cells[4].Value.ToString();
        }

        private void ClearTimer_Tick(object sender, EventArgs e) // Timer event to clear selection in the DataGridView after a short delay
        {
            dgvPayment.ClearSelection();
            clearTimer.Stop();
        }

        // <--------------------- Internal Helper Methods ----------------->

        private void LoadData() // Method to load booking data from the database and display it in the DataGridView
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"SELECT P.*, PM.MethodName FROM Payment AS P INNER JOIN PaymentMethods AS PM ON P.MethodID = PM.MethodID WHERE BookingID = {bookingID} ORDER BY P.PaymentID; SELECT * FROM PaymentMethods ORDER BY MethodID;";
                var adp = new SqlDataAdapter(cmd);
                var ds = new DataSet();
                adp.Fill(ds);
                con.Close();

                dgvPayment.AutoGenerateColumns = false;
                dgvPayment.DataSource = ds.Tables[0];
                dgvPayment.Refresh();

                cbMethod.DataSource = ds.Tables[1];
                cbMethod.DisplayMember = "MethodName";
                cbMethod.ValueMember = "MethodID";
                cbMethod.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Load Failed");
                return;
            }
        }

        private void ClearFields() // Method to clear input fields and reset the form state
        {
            txtID.Text = "Auto Generated";
            cbMethod.SelectedIndex = -1;
            txtAmount.Text = "";
            dtpDate.Value = DateTime.Now;
            txtReference.Text = "";
            dgvPayment.ClearSelection();
            this.CalculateDue();
        }

        private bool ValidateFields() // Validate input fields before saving
        {
            sbyte paymentMethodIndex = (sbyte) cbMethod.SelectedIndex;
            string amountText = txtAmount.Text;
            DateTime paymentDate = dtpDate.Value;
            string reference = txtReference.Text;
            double paymentAmount;

            if (amountDue <= 0 && txtID.Text == "Auto Generated") // No amount due
            {
                MessageBox.Show("No amount due. Cannot add more payments.", "Validation Error");
                return false;
            }

            if (paymentMethodIndex < 0) // Check if payment method selected
            {
                MessageBox.Show("Please select a payment method.", "Validation Error");
                return false;
            }

            try // Validate that payment amount is double
            {
                paymentAmount = double.Parse(amountText);
            } catch (Exception)
            {
                MessageBox.Show("Please enter a valid payment amount.", "Validation Error");
                return false;
            }

            if (paymentAmount < 1 || paymentAmount > 999999.99) // // Validate that capacity is within acceptable range
            {
                MessageBox.Show($"Payment amount must be between 1 and 999,999.99.", "Validation Error");
                return false;
            }

            if (txtID.Text == "Auto Generated" && paymentAmount > amountDue) // Validate that payment amount does not exceed amount due when adding new payment
            {
                MessageBox.Show($"Payment amount cannot exceed the amount due of {amountDue} Tk.", "Validation Error");
                return false;
            }

            if (paymentDate > DateTime.Now) // Validate payment date isn't in the future
            {
                MessageBox.Show("Payment date cannot be in the future.", "Validation Error");
                return false;
            }

            if (string.IsNullOrWhiteSpace(reference)) // Validate that reference is not empty
            {
                MessageBox.Show("Please enter a valid reference.", "Validation Error");
                return false;
            }

            if (reference.Length < 1 || reference.Length > 128) // Validate that reference length is within acceptable range
            {
                MessageBox.Show("Reference must be between 1 and 64 characters.", "Validation Error");
                return false;
            }

            return true; // All validations passes
        }

        private void CalculateDue()
        {
            double amountPaid = 0;
            for (int i = 0; i < dgvPayment.Rows.Count; i++)
            {
                amountPaid += double.Parse(dgvPayment.Rows[i].Cells[2].Value.ToString());
            }

             this.amountDue = totalBill - amountPaid;
            lblAmountDue.Text = $"Amount Due: {amountDue} Tk";
        }
    }
}
