﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS.ManagementPanels
{
    public partial class WardenInfo : UserControl
    {
        public WardenInfo()
        {
            InitializeComponent();
        }

        // <---------- EVENT HANDLERS ---------->

        private void WardenInfo_Load(object sender, EventArgs e) // Load event to initialize data when the UserControl is loaded
        {
            this.LoadData();
            clearTimer.Start();
        }

        private void BtnRefresh_Click(object sender, EventArgs e) // Refresh button to reload data from the database
        {
            this.LoadData();
            this.ClearFields();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "") // Ensure a student is selected before saving
            {
                MessageBox.Show("Create a warden from \"Manage User Info\" tab.", "Cannot Create Warden");
                return;
            }

            if (!this.ValidateFields()) return;

            string wName = txtName.Text.Trim();
            int wDormID = (int) cbDorm.SelectedValue;
            string wShift = cbShift.SelectedItem.ToString();
            DateTime wJoiningDate = dtpJoiningDate.Value;
            double wSalary = double.Parse(txtSalary.Text.Trim());

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"UPDATE Users SET Name = '{wName}' WHERE UserID = {txtID.Text}; UPDATE WardenInfo SET DormID = {wDormID}, Shift = '{wShift}', JoiningDate = '{wJoiningDate.ToString("yyyy-MM-dd")}', Salary = {wSalary} WHERE WardenID = {txtID.Text};";
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Save Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();

            MessageBox.Show("Warden information updated successfully.", "Success");
        }

        private void DgvWardenInfo_CellClick(object sender, DataGridViewCellEventArgs e) // Cell click event to populate input fields with the selected warden's information
        {
            if (e.RowIndex < 0) return;

            txtID.Text = dgvWardenInfo.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtName.Text = dgvWardenInfo.Rows[e.RowIndex].Cells[1].Value.ToString();
            cbDorm.SelectedValue = dgvWardenInfo.Rows[e.RowIndex].Cells[6].Value;
            cbShift.SelectedItem = dgvWardenInfo.Rows[e.RowIndex].Cells[3].Value;
            dtpJoiningDate.Value = Convert.ToDateTime(dgvWardenInfo.Rows[e.RowIndex].Cells[4].Value);
            txtSalary.Text = dgvWardenInfo.Rows[e.RowIndex].Cells[5].Value.ToString();
        }

        private void ClearTimer_Tick(object sender, EventArgs e) // Timer to clear selection in the DataGridView after a short delay
        {
            dgvWardenInfo.ClearSelection();
            clearTimer.Stop();
        }

        // <---------- HELPER METHODS ---------->

        private void LoadData() // Load data from the database and bind it to the DataGridView
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "SELECT U.Name, WI.*, D.DormName FROM WardenInfo AS WI INNER JOIN Users AS U ON U.UserID = WI.WardenID INNER JOIN Dormitory AS D ON D.DormID = WI.DormID ORDER BY WI.WardenID; SELECT * FROM Dormitory ORDER BY DormID;";

                var adp = new SqlDataAdapter(cmd);
                var ds = new DataSet();
                adp.Fill(ds);
                con.Close();

                dgvWardenInfo.AutoGenerateColumns = false;
                dgvWardenInfo.DataSource = ds.Tables[0];
                dgvWardenInfo.Refresh();

                cbDorm.DataSource = ds.Tables[1];
                cbDorm.DisplayMember = "DormName";
                cbDorm.ValueMember = "DormID";
                cbDorm.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Load Data Failed");
                return;
            }
        }

        private void ClearFields() // Clear all input fields
        {
            txtID.Text = "";
            txtName.Text = "";
            cbDorm.SelectedIndex = -1;
            cbShift.SelectedIndex = -1;
            dtpJoiningDate.Value = DateTime.Now;
            txtSalary.Text = "";
            dgvWardenInfo.ClearSelection();
        }   

        private bool ValidateFields()
        {
            string wName = txtName.Text;
            sbyte wDormIndex = (sbyte) cbDorm.SelectedIndex;
            sbyte wShiftIndex = (sbyte)cbShift.SelectedIndex;
            DateTime wJoiningDate = dtpJoiningDate.Value;
            string wSalaryText = txtSalary.Text;
            double wSalary;

            if (string.IsNullOrWhiteSpace(wName)) // Validate warden name
            {
                MessageBox.Show("Please enter a valid warden name.", "Validation Error");
                return false;
            }

            if (wName.Length < 1 || wName.Length > 128) // Validate warden name length
            {
                MessageBox.Show("Warden name must be between 1 and 128 characters.", "Validation Error");
                return false;
            }

            if (wDormIndex < 0) // No dormitory selected
            {
                MessageBox.Show("Please select a dormitory.", "Validation Error");
                return false;
            }

            if (wShiftIndex < 0) // No shift selected
            {
                MessageBox.Show("Please select a shift.", "Validation Error");
                return false;
            }

            if (wJoiningDate > DateTime.Now) // Joining date is in the future
            {
                MessageBox.Show("Joining date cannot be in the future.", "Validation Error");
                return false;
            }

            try // Invalid salary input
            {
                wSalary = double.Parse(wSalaryText);
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter a valid salary amount.", "Validation Error");
                return false;
            }

            if (wSalary < 0 || wSalary > 999999.99) // Salary out of range
            {
                MessageBox.Show("Salary must be between 0 and 999999.99.", "Validation Error");
                return false;
            }

            return true; // All validations passed
        }
    }
}
