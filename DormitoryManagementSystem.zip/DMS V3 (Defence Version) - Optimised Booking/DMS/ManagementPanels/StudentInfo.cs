﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS.ManagementPanels
{
    public partial class StudentInfo : UserControl
    {
        public StudentInfo()
        {
            InitializeComponent();
        }

        // <---------- EVENT HANDLERS ---------->

        private void StudentInfo_Load(object sender, EventArgs e) // Load event to initialize data when the UserControl is loaded
        {
            this.LoadData();
            clearTimer.Start();
        }

        private void BtnRefresh_Click(object sender, EventArgs e) // Refresh button to reload data from the database
        {
            this.LoadData();
            this.ClearFields();
        }

        private void BtnSave_Click(object sender, EventArgs e) // Save button to update the selected student's information in the database
        {
            if (txtID.Text == "") // Ensure a student is selected before saving
            {
                MessageBox.Show("Create a student from \"Manage User Info\" tab.", "Cannot Create Student");
                return;
            }

            if (!this.ValidateFields()) return;

            string sName = txtName.Text.Trim();
            string sInstituteID = txtInstituteID.Text.Trim();
            string sDept = cbDept.SelectedItem.ToString();
            string sProgram = cbProgram.SelectedItem.ToString();
            byte sYearOfStudy = (byte)(cbYearOfStudy.SelectedIndex + 1);

            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"UPDATE Users SET Name = '{sName}' WHERE UserID = {txtID.Text}; UPDATE StudentInfo SET InstituteID = '{sInstituteID}', Department = '{sDept}', Program = '{sProgram}', YearOfStudy = {sYearOfStudy} WHERE StudentID = {txtID.Text}";
                cmd.ExecuteNonQuery();
                con.Close();
            } catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Save Failed");
                return;
            }

            this.LoadData();
            this.ClearFields();

            MessageBox.Show("Student information updated successfully.", "Success");
        }

        private void DgvStudentInfo_CellClick(object sender, DataGridViewCellEventArgs e) // Populate input fields when a row in the DataGridView is clicked
        {
            if (e.RowIndex < 0) return;

            txtID.Text = dgvStudentInfo.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtName.Text = dgvStudentInfo.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtInstituteID.Text = dgvStudentInfo.Rows[e.RowIndex].Cells[2].Value.ToString();
            cbDept.SelectedItem = dgvStudentInfo.Rows[e.RowIndex].Cells[3].Value;
            cbProgram.SelectedItem = dgvStudentInfo.Rows[e.RowIndex].Cells[4].Value;

            sbyte yearOfStudy = sbyte.Parse(dgvStudentInfo.Rows[e.RowIndex].Cells[5].Value.ToString());
            cbYearOfStudy.SelectedIndex = yearOfStudy - 1;
        }

        private void ClearTimer_Tick(object sender, EventArgs e) // Timer to clear selection in the DataGridView after a short delay
        {
            dgvStudentInfo.ClearSelection();
            clearTimer.Stop();
        }

        // <---------- HELPER METHODS ---------->

        private void LoadData() // Load data from the database and bind it to the DataGridView
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "SELECT U.Name, SI.* FROM StudentInfo AS SI INNER JOIN Users AS U ON U.UserID = SI.StudentID ORDER BY SI.StudentID";

                var adp = new SqlDataAdapter(cmd);
                var dt = new DataTable();
                adp.Fill(dt);
                con.Close();

                dgvStudentInfo.AutoGenerateColumns = false;
                dgvStudentInfo.DataSource = dt;
                dgvStudentInfo.Refresh();
            } catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Load Data Failed");
                return;
            }
        }

        private void ClearFields() // Clear all input fields
        {
            txtID.Text = "";
            txtName.Text = "";
            txtInstituteID.Text = "";
            cbDept.SelectedIndex = -1;
            cbProgram.SelectedIndex = -1;
            cbYearOfStudy.SelectedIndex = -1;
            dgvStudentInfo.ClearSelection();
        }

        private bool ValidateFields()
        {
            string sName = txtName.Text.Trim();
            string sInstituteID = txtInstituteID.Text.Trim();
            sbyte sDeptIndex = (sbyte) cbDept.SelectedIndex;
            sbyte sProgramIndex = (sbyte) cbProgram.SelectedIndex;
            sbyte sYearOfStudyIndex = (sbyte) cbYearOfStudy.SelectedIndex;

            if (string.IsNullOrWhiteSpace(sName)) // Validate student name
            {
                MessageBox.Show("Please enter a valid student name.", "Validation Error");
                return false;
            }

            if (sName.Length < 1 || sName.Length > 128) // Validate student name length
            {
                MessageBox.Show("Student name must be between 1 and 128 characters.", "Validation Error");
                return false;
            }

            if (string.IsNullOrWhiteSpace(sInstituteID)) // Validate institute ID
            {
                MessageBox.Show("Please enter a valid institute ID.", "Validation Error");
                return false;
            }

            if (sInstituteID.Length < 1 || sInstituteID.Length > 10) // Validate institute ID length
            {
                MessageBox.Show("Institute ID must be between 1 and 10 characters.", "Validation Error");
                return false;
            }

            if (sDeptIndex < 0) // Validate department selection
            {
                MessageBox.Show("Please select a department.", "Validation Error");
                return false;
            }

            if (sProgramIndex < 0) // Validate program selection
            {
                MessageBox.Show("Please select a program.", "Validation Error");
                return false;
            }

            if (sYearOfStudyIndex < 0) // Validate year of study selection
            {
                MessageBox.Show("Please select a year of study.", "Validation Error");
                return false;
            }

            return true; // All validations passed
        }
    }
}
