﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnPassShow_MouseHover(object sender, EventArgs e)
        {
            txtPass.UseSystemPasswordChar = false;
           
        }

        private void btnPassShow_MouseLeave(object sender, EventArgs e)
        {
            txtPass.UseSystemPasswordChar=true;
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            RegistrationForm rf = new RegistrationForm();
            rf.Owner = this;
            rf.Show();
            this.Hide();
        }


        private void btnLogin_Click(object sender, EventArgs e)
        {
            string Email = txtEmail.Text;
            string Pass = txtPass.Text;
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"Select * From Users Where Email = '{Email}' AND Password = '{Pass}'";

                DataTable dt = new DataTable();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(dt);

                if (dt.Rows.Count != 1) {
                    MessageBox.Show("Invalid Email or Password!");
                    return;
                }

                ApplicationHelper.CurrentUserName = dt.Rows[0]["Name"].ToString();
                ApplicationHelper.CurrentUserRole = dt.Rows[0]["UserType"].ToString();
                ApplicationHelper.CurrentUserID = int.Parse(dt.Rows[0]["UserID"].ToString());
                ApplicationHelper.CurrentUserGender = dt.Rows[0]["Gender"].ToString();

                if (ApplicationHelper.CurrentUserRole == "SuperAdmin" || ApplicationHelper.CurrentUserRole == "Admin" || ApplicationHelper.CurrentUserRole == "Warden") {
                    AdminDashboard ad = new AdminDashboard();
                    ad.Owner = this;
                    ad.Show();
                    this.Hide();
                    txtEmail.Text = "";
                    txtPass.Text = "";
                }
                else if (ApplicationHelper.CurrentUserRole == "Student")
                {
                    Student stu = new Student();
                    stu.Owner = this;
                    stu.Show();
                    this.Hide();
                    txtEmail.Text = "";
                    txtPass.Text = "";
                }
                con.Close();
            }
            catch (Exception ex) { 
                MessageBox.Show(ex.Message );
            }
        }
    }
}
