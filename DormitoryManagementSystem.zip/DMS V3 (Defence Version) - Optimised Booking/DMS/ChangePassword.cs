﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DMS
{
    public partial class ChangePassword : Form
    {
        public ChangePassword()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string newPass = txtNewPass.Text;
            string confPass = txtConfPass.Text;

            if (newPass == "" || confPass == "")
            {
                MessageBox.Show("Password not entered");
            }

            if (newPass != confPass)
            {
                MessageBox.Show("Passwords do not match");
                return;
            }

            try {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"update Users set Password = '{newPass}' where UserID = {ApplicationHelper.CurrentUserID}";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Password updated");
                con.Close();
                this.Close();
            }
            catch(Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnShowPass_MouseHover(object sender, EventArgs e)
        {
            txtNewPass.UseSystemPasswordChar = false;

        }

        private void btnShowPass_MouseLeave(object sender, EventArgs e)
        {
            txtNewPass.UseSystemPasswordChar = true;
        }

        private void btnShowNewPass_MouseHover(object sender, EventArgs e)
        {
            txtConfPass.UseSystemPasswordChar = false;
        }

        private void btnShowNewPass_MouseLeave(object sender, EventArgs e)
        {
            txtConfPass.UseSystemPasswordChar = true;
        }
    }
}
