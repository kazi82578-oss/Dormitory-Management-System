﻿namespace DMS
{
    partial class ChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNewPass = new System.Windows.Forms.TextBox();
            this.txtConfPass = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnShowPass = new System.Windows.Forms.Button();
            this.btnShowNewPass = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 73);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "New Password:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 114);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Confirm Password:";
            // 
            // txtNewPass
            // 
            this.txtNewPass.Location = new System.Drawing.Point(179, 72);
            this.txtNewPass.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNewPass.Name = "txtNewPass";
            this.txtNewPass.Size = new System.Drawing.Size(154, 20);
            this.txtNewPass.TabIndex = 5;
            this.txtNewPass.UseSystemPasswordChar = true;
            // 
            // txtConfPass
            // 
            this.txtConfPass.Location = new System.Drawing.Point(179, 115);
            this.txtConfPass.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtConfPass.Name = "txtConfPass";
            this.txtConfPass.Size = new System.Drawing.Size(154, 20);
            this.txtConfPass.TabIndex = 6;
            this.txtConfPass.UseSystemPasswordChar = true;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(170, 157);
            this.btnSubmit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(65, 27);
            this.btnSubmit.TabIndex = 15;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnShowPass
            // 
            this.btnShowPass.BackgroundImage = global::DMS.Properties.Resources.vecteezy_hidden_icon_visible_invisible_icon_eye_icon_look_and_22782488;
            this.btnShowPass.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnShowPass.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnShowPass.Location = new System.Drawing.Point(307, 70);
            this.btnShowPass.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnShowPass.Name = "btnShowPass";
            this.btnShowPass.Size = new System.Drawing.Size(25, 21);
            this.btnShowPass.TabIndex = 22;
            this.btnShowPass.UseCompatibleTextRendering = true;
            this.btnShowPass.UseVisualStyleBackColor = true;
            this.btnShowPass.MouseLeave += new System.EventHandler(this.btnShowPass_MouseLeave);
            this.btnShowPass.MouseHover += new System.EventHandler(this.btnShowPass_MouseHover);
            // 
            // btnShowNewPass
            // 
            this.btnShowNewPass.BackgroundImage = global::DMS.Properties.Resources.vecteezy_hidden_icon_visible_invisible_icon_eye_icon_look_and_22782488;
            this.btnShowNewPass.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnShowNewPass.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnShowNewPass.Location = new System.Drawing.Point(307, 113);
            this.btnShowNewPass.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnShowNewPass.Name = "btnShowNewPass";
            this.btnShowNewPass.Size = new System.Drawing.Size(25, 21);
            this.btnShowNewPass.TabIndex = 23;
            this.btnShowNewPass.UseCompatibleTextRendering = true;
            this.btnShowNewPass.UseVisualStyleBackColor = true;
            this.btnShowNewPass.MouseLeave += new System.EventHandler(this.btnShowNewPass_MouseLeave);
            this.btnShowNewPass.MouseHover += new System.EventHandler(this.btnShowNewPass_MouseHover);
            // 
            // ChangePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Wheat;
            this.ClientSize = new System.Drawing.Size(419, 232);
            this.Controls.Add(this.btnShowNewPass);
            this.Controls.Add(this.btnShowPass);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtConfPass);
            this.Controls.Add(this.txtNewPass);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "ChangePassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChangePassword";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNewPass;
        private System.Windows.Forms.TextBox txtConfPass;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnShowPass;
        private System.Windows.Forms.Button btnShowNewPass;
    }
}