﻿using DMS.ManagementPanels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS
{
    public partial class AdminDashboard : Form
    {
        public AdminDashboard()
        {
            InitializeComponent();
        }

        private void AdminDashboard_Load(object sender, EventArgs e)
        {
            lblGreetings.Text = $"Welcome, {ApplicationHelper.CurrentUserName}";

            if (ApplicationHelper.CurrentUserRole == "Warden")
            {
                this.Text = "Warden Dashboard";
                this.btnPaymentMethods.Visible = false;
                this.btnDorm.Visible = false;
                this.btnRoomType.Visible = false;
                this.btnRoomRates.Visible = false;
                this.btnMealSlots.Visible = false;
                this.btnUserInfo.Visible = false;
                this.btnStudentInfo.Visible = false;
                this.btnWardenInfo.Visible = false;
            }
        }

        private void AdminDashboard_FormClosing(object sender, FormClosingEventArgs e) // Show login page
        {
            if (this.Owner != null) this.Owner.Show();
        }

        private void BtnHome_Click(object sender, EventArgs e) // Home button to clear the panel host
        {
            panelHost.Controls.Clear();
        }

        private void BtnBookings_Click(object sender, EventArgs e) // Bookings button to load the Booking UserControl
        {
            panelHost.Controls.Clear();
            var subForm = new ManagementPanels.Booking();
            subForm.Dock = DockStyle.Fill;
            panelHost.Controls.Add(subForm);
        }

        private void BtnPaymentMethods_Click(object sender, EventArgs e) // Payment Methods button to load the PaymentMethods UserControl
        {
            panelHost.Controls.Clear();
            var subForm = new ManagementPanels.PaymentMethods();
            subForm.Dock = DockStyle.Fill;
            panelHost.Controls.Add(subForm);
        }

        private void BtnDorm_Click(object sender, EventArgs e) // Dormitory button to load the Dormitory UserControl
        {
            panelHost.Controls.Clear();
            var subForm = new ManagementPanels.Dormitory();
            subForm.Dock = DockStyle.Fill;
            panelHost.Controls.Add(subForm);
        }

        private void BtnRoomType_Click(object sender, EventArgs e) // Room Types button to load the RoomTypes UserControl
        {
            panelHost.Controls.Clear();
            var subForm = new ManagementPanels.RoomType();
            subForm.Dock = DockStyle.Fill;
            panelHost.Controls.Add(subForm);
        }

        private void BtnRoomRates_Click(object sender, EventArgs e) // Room Rates button to load the RoomRates UserControl
        {
            panelHost.Controls.Clear();
            var subForm = new ManagementPanels.DormRoomRate();
            subForm.Dock = DockStyle.Fill;
            panelHost.Controls.Add(subForm);
        }

        private void BtnMealSlots_Click(object sender, EventArgs e) // Meal Slots button to load the MealSlot UserControl
        {
            panelHost.Controls.Clear();
            var subForm = new ManagementPanels.MealSlot();
            subForm.Dock = DockStyle.Fill;
            panelHost.Controls.Add(subForm);
        }

        private void BtnUserInfo_Click(object sender, EventArgs e) // Users button to load the Users UserControl
        {
            panelHost.Controls.Clear();
            var subForm = new ManagementPanels.Users();
            subForm.Dock = DockStyle.Fill;
            panelHost.Controls.Add(subForm);
        }

        private void BtnStudentInfo_Click(object sender, EventArgs e) // Student Info button to load the StudentInfo UserControl
        {
            panelHost.Controls.Clear();
            var subForm = new ManagementPanels.StudentInfo();
            subForm.Dock = DockStyle.Fill;
            panelHost.Controls.Add(subForm);
        }

        private void BtnWardenInfo_Click(object sender, EventArgs e) // Warden Info button to load the WardenInfo UserControl
        {
            panelHost.Controls.Clear();
            var subForm = new ManagementPanels.WardenInfo();
            subForm.Dock = DockStyle.Fill;
            panelHost.Controls.Add(subForm);
        }

        private void BtnLogout_Click(object sender, EventArgs e) // Logout button to return to login form
        {
            if (this.Owner != null)
            {
                this.Owner.Show();
                this.Close();
            }
        }

        private void BtnChangePass_Click(object sender, EventArgs e) // Change password button
        {
            new ManagementPanels.ChangePassword().Show();
        }
    }
}
