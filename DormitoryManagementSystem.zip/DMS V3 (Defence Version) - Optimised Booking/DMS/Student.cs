﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMS
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }

        private void Student_Load(object sender, EventArgs e)
        {
            this.dataLoad();
        }

        private void Student_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.Owner != null)
            {
                this.Owner.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dgvBookinginfo.Rows.Count; i++)
            {
                string rowStatus = dgvBookinginfo.Rows[i].Cells[5].Value.ToString();
                if (rowStatus == "Confirmed" || rowStatus == "Pending")
                {
                    MessageBox.Show("Cannot create new booking with existing confirmed or pending booking.");
                    return;
                }
            }

            NewBooking nb = new NewBooking();
            nb.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (bkID.Text == "")
            {
                MessageBox.Show("Select a booking");
                return;
            }

            if (bkStatus.Text == "Confirmed")
            {
                Payment pm = new Payment(bkID.Text);
                pm.Show();
            } else
            {
                MessageBox.Show("Only can see payment for confirm booking");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
           DialogResult result = MessageBox.Show("Do you want to change your password?","Confirm", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) { 
                ChangePassword cp = new ChangePassword();
                cp.Show();
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.dataLoad();
        }

        private void dataLoad()
        {
            try
            {
                var con = new SqlConnection();
                con.ConnectionString = ApplicationHelper.ConnectionString;
                con.Open();

                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = $"select b.BookingID, d.DormName, rt.RoomType, b.LeaseStart, b.LeaseEnd, b.Status, b.TotalBill from Booking AS b inner join Users AS u ON u.UserID = b.StudentID inner join DormRoomRate AS drr ON drr.RateID = b.RateID inner join Dormitory AS d ON d.DormID = drr.DormID inner join RoomType AS rt ON rt.RoomTypeID = drr.RoomTypeID where b.StudentID = {ApplicationHelper.CurrentUserID}";

                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                dgvBookinginfo.AutoGenerateColumns = false;
                dgvBookinginfo.DataSource = dt;
                dgvBookinginfo.Refresh();
                dgvBookinginfo.ClearSelection();

                con.Close();
            } catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dgvBookinginfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            bkID.Text = dgvBookinginfo.Rows[e.RowIndex].Cells[0].Value.ToString();
            bkStatus.Text = dgvBookinginfo.Rows[e.RowIndex].Cells[5].Value.ToString();
        }
    }
}
